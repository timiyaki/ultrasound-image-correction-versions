@echo off
setlocal
cd /d "%~dp0"
set "PYEXE=C:\Users\timiy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if exist "%PYEXE%" goto install
set "PYEXE=python"
:install
"%PYEXE%" -m pip install -r "%~dp0requirements-training.txt"
if errorlevel 1 goto failed
echo.
echo U-Net training components installed.
pause
exit /b 0
:failed
echo.
echo Installation failed. Check network access and available disk space.
pause
exit /b 1
