from __future__ import annotations

import argparse
import random
from pathlib import Path

import numpy as np
from PIL import Image


def main():
    try:
        import torch
        import torch.nn as nn
        from torch.utils.data import DataLoader, Dataset
    except ImportError as exc:
        raise SystemExit(
            "PyTorch is not installed. Run the training-component installer first."
        ) from exc

    class PairDataset(Dataset):
        def __init__(self, root: Path, list_file: Path, size: int, augment: bool):
            self.root = root
            self.size = size
            self.augment = augment
            self.items = []
            for line in list_file.read_text(encoding="utf-8").splitlines():
                parts = line.strip().split()
                if len(parts) >= 2:
                    self.items.append((root / parts[0], root / parts[1]))
            if not self.items:
                raise ValueError(f"No image/mask pairs in {list_file}")

        def __len__(self):
            return len(self.items)

        def __getitem__(self, index):
            image_path, mask_path = self.items[index]
            image = Image.open(image_path).convert("L").resize(
                (self.size, self.size), Image.Resampling.BILINEAR
            )
            mask = Image.open(mask_path).convert("L").resize(
                (self.size, self.size), Image.Resampling.NEAREST
            )
            image_array = np.asarray(image, dtype=np.float32) / 255.0
            mask_array = (np.asarray(mask, dtype=np.float32) >= 127.0).astype(np.float32)
            if self.augment:
                if random.random() < 0.5:
                    image_array = np.flip(image_array, axis=1)
                    mask_array = np.flip(mask_array, axis=1)
                if random.random() < 0.35:
                    gain = random.uniform(0.88, 1.12)
                    offset = random.uniform(-0.05, 0.05)
                    image_array = np.clip(image_array * gain + offset, 0.0, 1.0)
            image_array = np.ascontiguousarray(image_array[None, ...])
            mask_array = np.ascontiguousarray(mask_array[None, ...])
            return torch.from_numpy(image_array), torch.from_numpy(mask_array)

    class DoubleConv(nn.Module):
        def __init__(self, in_channels, out_channels):
            super().__init__()
            self.block = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
                nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )

        def forward(self, x):
            return self.block(x)

    class UNet(nn.Module):
        def __init__(self, base=24):
            super().__init__()
            self.e1 = DoubleConv(1, base)
            self.e2 = DoubleConv(base, base * 2)
            self.e3 = DoubleConv(base * 2, base * 4)
            self.e4 = DoubleConv(base * 4, base * 8)
            self.pool = nn.MaxPool2d(2)
            self.center = DoubleConv(base * 8, base * 16)
            self.u4 = nn.ConvTranspose2d(base * 16, base * 8, 2, stride=2)
            self.d4 = DoubleConv(base * 16, base * 8)
            self.u3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
            self.d3 = DoubleConv(base * 8, base * 4)
            self.u2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
            self.d2 = DoubleConv(base * 4, base * 2)
            self.u1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
            self.d1 = DoubleConv(base * 2, base)
            self.out = nn.Conv2d(base, 1, 1)

        def forward(self, x):
            e1 = self.e1(x)
            e2 = self.e2(self.pool(e1))
            e3 = self.e3(self.pool(e2))
            e4 = self.e4(self.pool(e3))
            c = self.center(self.pool(e4))
            d4 = self.d4(torch.cat([self.u4(c), e4], dim=1))
            d3 = self.d3(torch.cat([self.u3(d4), e3], dim=1))
            d2 = self.d2(torch.cat([self.u2(d3), e2], dim=1))
            d1 = self.d1(torch.cat([self.u1(d2), e1], dim=1))
            return self.out(d1)

    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch", type=int, default=2)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--size", type=int, default=512)
    args = parser.parse_args()

    torch.manual_seed(2026)
    np.random.seed(2026)
    random.seed(2026)
    root = Path(args.dataset)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    train_data = PairDataset(root, root / "train.txt", args.size, augment=True)
    val_file = root / "val.txt"
    val_data = (
        PairDataset(root, val_file, args.size, augment=False)
        if val_file.is_file() and val_file.read_text(encoding="utf-8").strip()
        else None
    )
    train_loader = DataLoader(train_data, batch_size=args.batch, shuffle=True, num_workers=0)
    val_loader = (
        DataLoader(val_data, batch_size=args.batch, shuffle=False, num_workers=0)
        if val_data
        else None
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = UNet().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    bce = nn.BCEWithLogitsLoss()

    def loss_function(logits, target):
        probabilities = torch.sigmoid(logits)
        intersection = (probabilities * target).sum(dim=(1, 2, 3))
        dice = (2.0 * intersection + 1.0) / (
            probabilities.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + 1.0
        )
        return bce(logits, target) + (1.0 - dice.mean())

    best_score = -1.0
    best_state = None
    for epoch in range(1, args.epochs + 1):
        model.train()
        losses = []
        for image, mask in train_loader:
            image, mask = image.to(device), mask.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(image)
            loss = loss_function(logits, mask)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        model.eval()
        dice_scores = []
        loader = val_loader if val_loader is not None else train_loader
        with torch.no_grad():
            for image, mask in loader:
                image, mask = image.to(device), mask.to(device)
                prediction = torch.sigmoid(model(image)) >= 0.5
                intersection = (prediction * mask.bool()).sum(dim=(1, 2, 3)).float()
                denominator = prediction.sum(dim=(1, 2, 3)).float() + mask.sum(dim=(1, 2, 3))
                dice = (2.0 * intersection + 1.0) / (denominator + 1.0)
                dice_scores.extend(dice.cpu().tolist())
        score = float(np.mean(dice_scores))
        print(
            f"PROGRESS {epoch}/{args.epochs} loss={np.mean(losses):.5f} dice={score:.5f}",
            flush=True,
        )
        if score > best_score:
            best_score = score
            best_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}

    if best_state is not None:
        model.load_state_dict(best_state)
    model = model.cpu().eval()
    checkpoint = output.with_suffix(".pt")
    torch.save(
        {
            "model_state": model.state_dict(),
            "input_size": args.size,
            "best_dice": best_score,
        },
        checkpoint,
    )
    dummy = torch.zeros(1, 1, args.size, args.size, dtype=torch.float32)
    torch.onnx.export(
        model,
        dummy,
        output,
        input_names=["image"],
        output_names=["fetal_roi_logits"],
        dynamic_axes={"image": {0: "batch"}, "fetal_roi_logits": {0: "batch"}},
        opset_version=17,
    )
    print(f"DONE onnx={output} checkpoint={checkpoint} best_dice={best_score:.5f}", flush=True)


if __name__ == "__main__":
    main()
