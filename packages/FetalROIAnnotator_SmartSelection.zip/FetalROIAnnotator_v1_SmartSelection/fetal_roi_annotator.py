from __future__ import annotations

import json
import math
import queue
import subprocess
import sys
import threading
from pathlib import Path

import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk

from ultrasound_bin_gui import (
    ProcessParams,
    _edge_aware_neighbor_mean,
    _edge_conductance_4,
    binary_dilate,
    binary_erode,
    box_mean,
    dsc_scan_convert,
    read_capture_metadata,
    read_frames,
    scan_safe_mask,
)


APP_TITLE = "胎儿 ROI 智能标注工具 Annotator v1"
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def disk_mask(shape: tuple[int, int], x: int, y: int, radius: int) -> np.ndarray:
    result = np.zeros(shape, dtype=bool)
    y0, y1 = max(0, y - radius), min(shape[0], y + radius + 1)
    x0, x1 = max(0, x - radius), min(shape[1], x + radius + 1)
    yy, xx = np.ogrid[y0:y1, x0:x1]
    result[y0:y1, x0:x1] = (yy - y) ** 2 + (xx - x) ** 2 <= radius * radius
    return result


def gradient_map(frame: np.ndarray) -> np.ndarray:
    gray = frame.astype(np.float32)
    smooth = box_mean(gray[None, ...], 1)[0]
    padded = np.pad(smooth, ((1, 1), (1, 1)), mode="reflect")
    gradient = np.maximum.reduce(
        [
            np.abs(smooth - padded[:-2, 1:-1]),
            np.abs(smooth - padded[2:, 1:-1]),
            np.abs(smooth - padded[1:-1, :-2]),
            np.abs(smooth - padded[1:-1, 2:]),
        ]
    )
    valid = gradient[frame > 0]
    scale = float(np.percentile(valid, 92)) if valid.size else 1.0
    return np.clip(gradient / max(scale, 1.0), 0.0, 1.0)


def smart_wand_region(
    frame: np.ndarray,
    x: int,
    y: int,
    tolerance: float,
    edge_protection: float,
    steps: int,
) -> np.ndarray:
    """Photoshop-like contiguous selection with ultrasound edge protection."""
    safe = scan_safe_mask(frame, erosion_pixels=1)
    if not safe[y, x]:
        return np.zeros(frame.shape, dtype=bool)
    gray = frame.astype(np.float32)
    radius = 2
    patch = gray[max(0, y - radius) : y + radius + 1, max(0, x - radius) : x + radius + 1]
    center = float(np.median(patch))
    spread = max(4.0, float(tolerance) * 0.52)
    similarity = np.exp(-0.5 * ((gray - center) / spread) ** 2)
    seed = disk_mask(frame.shape, x, y, 2) & safe
    probability = seed.astype(np.float32)
    conductance_scale = max(5.0, 32.0 - 23.0 * float(edge_protection))
    conductances, conductance_sum = _edge_conductance_4(gray, conductance_scale)
    envelope = safe & (np.abs(gray - center) <= max(float(tolerance), 5.0) * 1.35)
    for _ in range(max(4, int(steps))):
        neighbor = _edge_aware_neighbor_mean(probability, conductances, conductance_sum)
        supported = similarity * np.clip(neighbor * 3.0, 0.0, 1.0)
        probability = np.clip(0.60 * probability + 0.36 * neighbor + 0.10 * supported, 0.0, 1.0)
        probability[~envelope] = 0.0
        probability[seed] = 1.0
    selected = (probability >= 0.20) & envelope
    return binary_erode(binary_dilate(selected, 1), 1) & safe


def quick_selection(
    frame: np.ndarray,
    current_mask: np.ndarray,
    positive: np.ndarray,
    negative: np.ndarray,
    edge_protection: float,
    steps: int,
) -> np.ndarray:
    """Scribble-driven edge-aware foreground/background selection."""
    safe = scan_safe_mask(frame, erosion_pixels=1)
    gray = frame.astype(np.float32)
    positive_seed = (current_mask | positive) & safe & ~negative
    if not np.any(positive_seed):
        return current_mask.copy()
    pos_values = gray[positive_seed]
    pos_center = float(np.median(pos_values))
    pos_spread = max(float(1.4826 * np.median(np.abs(pos_values - pos_center))), 18.0)
    pos_like = np.exp(-0.5 * ((gray - pos_center) / (2.5 * pos_spread)) ** 2)
    if np.any(negative):
        neg_values = gray[negative & safe]
        if neg_values.size:
            neg_center = float(np.median(neg_values))
            neg_spread = max(float(1.4826 * np.median(np.abs(neg_values - neg_center))), 16.0)
            neg_like = np.exp(-0.5 * ((gray - neg_center) / (2.3 * neg_spread)) ** 2)
            foreground_score = pos_like / np.maximum(pos_like + neg_like, 1e-5)
        else:
            foreground_score = pos_like
    else:
        foreground_score = pos_like
    conductance_scale = max(6.0, 34.0 - 24.0 * float(edge_protection))
    conductances, conductance_sum = _edge_conductance_4(gray, conductance_scale)
    probability = positive_seed.astype(np.float32)
    envelope = binary_dilate(positive_seed, min(48, max(12, int(steps)))) & safe
    for _ in range(max(6, int(steps))):
        neighbor = _edge_aware_neighbor_mean(probability, conductances, conductance_sum)
        supported = foreground_score * np.clip(neighbor * 2.8, 0.0, 1.0)
        probability = np.clip(0.61 * probability + 0.35 * neighbor + 0.09 * supported, 0.0, 1.0)
        probability[~envelope] = 0.0
        probability[positive_seed] = 1.0
        probability[negative] = 0.0
    result = (probability >= 0.22) & safe & ~negative
    return binary_erode(binary_dilate(result, 1), 1) & safe


def refine_selection(
    frame: np.ndarray,
    mask: np.ndarray,
    smooth_steps: int,
    feather_radius: int,
    contrast: float,
    shift: int,
    edge_snap: float,
) -> np.ndarray:
    """Smooth, feather and snap a binary ROI boundary to strong reflection edges."""
    result = mask.astype(bool, copy=True)
    for _ in range(max(0, int(smooth_steps))):
        result = binary_erode(binary_dilate(result, 1), 1)
        result = binary_dilate(binary_erode(result, 1), 1)
    if shift > 0:
        result = binary_dilate(result, shift)
    elif shift < 0:
        result = binary_erode(result, -shift)
    radius = max(0, int(feather_radius))
    probability = result.astype(np.float32)
    if radius:
        probability = box_mean(probability[None, ...], radius)[0]
    if edge_snap > 0.0:
        gradient = gradient_map(frame)
        band_radius = max(2, radius + 2)
        band = binary_dilate(result, band_radius) & ~binary_erode(result, band_radius)
        threshold = 0.5 + float(contrast) * 0.16
        adaptive_threshold = threshold - float(edge_snap) * 0.18 * gradient
        refined_band = probability >= adaptive_threshold
        result = (result & ~band) | (refined_band & band)
    else:
        threshold = 0.5 + float(contrast) * 0.16
        result = probability >= threshold
    result &= scan_safe_mask(frame, erosion_pixels=1)
    return binary_erode(binary_dilate(result, 1), 1)


def overlay_selection(
    frame: np.ndarray,
    mask: np.ndarray,
    positive: np.ndarray | None,
    negative: np.ndarray | None,
    opacity: float,
) -> np.ndarray:
    rgb = np.repeat(frame[..., None], 3, axis=2).astype(np.float32)
    color = np.array([35.0, 220.0, 105.0], dtype=np.float32)
    alpha = float(opacity)
    rgb[mask] = (1.0 - alpha) * rgb[mask] + alpha * color
    boundary = mask & ~binary_erode(mask, 1)
    rgb[boundary] = (255, 220, 35)
    if positive is not None:
        rgb[positive] = (35, 255, 90)
    if negative is not None:
        rgb[negative] = (255, 55, 55)
    return np.rint(np.clip(rgb, 0.0, 255.0)).astype(np.uint8)


class FetalRoiAnnotator(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1460x930")
        self.minsize(1120, 760)
        self.option_add("*Font", ("Microsoft YaHei UI", 10))
        self.frames: list[np.ndarray] = []
        self.masks: list[np.ndarray] = []
        self.source_names: list[str] = []
        self.capture_metadata: dict = {}
        self.current_index = 0
        self.positive_scribble: np.ndarray | None = None
        self.negative_scribble: np.ndarray | None = None
        self.undo_stacks: list[list[np.ndarray]] = []
        self.redo_stacks: list[list[np.ndarray]] = []
        self.gradient_cache: list[np.ndarray | None] = []
        self.display_photo: ImageTk.PhotoImage | None = None
        self.display_scale = 1.0
        self.display_offset = (0.0, 0.0)
        self.stroke_active = False
        self.stroke_changed = False
        self.task_queue: queue.Queue = queue.Queue()
        self.busy = False
        self._build_ui()
        self.after(100, self._poll_queue)

    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky="nsew")
        left.rowconfigure(0, weight=1)
        left.columnconfigure(0, weight=1)
        scroll_canvas = tk.Canvas(left, width=350, highlightthickness=0)
        scrollbar = ttk.Scrollbar(left, orient="vertical", command=scroll_canvas.yview)
        scroll_canvas.configure(yscrollcommand=scrollbar.set)
        scroll_canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        controls = ttk.Frame(scroll_canvas, padding=12)
        window = scroll_canvas.create_window((0, 0), window=controls, anchor="nw")
        controls.bind(
            "<Configure>", lambda _e: scroll_canvas.configure(scrollregion=scroll_canvas.bbox("all"))
        )
        scroll_canvas.bind(
            "<Configure>", lambda e: scroll_canvas.itemconfigure(window, width=e.width)
        )
        controls.bind(
            "<Enter>",
            lambda _e: self.bind_all(
                "<MouseWheel>",
                lambda event: scroll_canvas.yview_scroll(-3 if event.delta > 0 else 3, "units"),
            ),
        )
        controls.bind("<Leave>", lambda _e: self.unbind_all("<MouseWheel>"))

        files = ttk.LabelFrame(controls, text="数据", padding=10)
        files.pack(fill="x", pady=(0, 10))
        self.source_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self._path_row(files, "采集目录/图片目录", self.source_var, self._browse_source)
        self._path_row(files, "数据集输出目录", self.output_var, self._browse_output)
        self.load_capture_button = ttk.Button(files, text="读取超声采集目录", command=self._load_capture)
        self.load_capture_button.pack(fill="x", pady=(3, 2))
        self.load_images_button = ttk.Button(files, text="读取普通图片目录", command=self._load_images)
        self.load_images_button.pack(fill="x", pady=2)
        self.dataset_var = tk.StringVar(value="请选择一组待标注图像。")
        ttk.Label(files, textvariable=self.dataset_var, wraplength=310).pack(fill="x", pady=(5, 0))

        tools = ttk.LabelFrame(controls, text="Photoshop式选区工具", padding=10)
        tools.pack(fill="x", pady=(0, 10))
        self.tool_var = tk.StringVar(value="智能选区")
        self.operation_var = tk.StringVar(value="加选")
        ttk.Label(tools, text="工具").grid(row=0, column=0, sticky="w")
        ttk.Combobox(
            tools,
            textvariable=self.tool_var,
            values=("智能选区", "快速选择", "精细画笔"),
            state="readonly",
            width=15,
        ).grid(row=0, column=1, sticky="ew", pady=2)
        ttk.Label(tools, text="操作").grid(row=1, column=0, sticky="w")
        ttk.Combobox(
            tools,
            textvariable=self.operation_var,
            values=("加选", "减选"),
            state="readonly",
            width=15,
        ).grid(row=1, column=1, sticky="ew", pady=2)
        self.tolerance_var = tk.DoubleVar(value=34)
        self.edge_protection_var = tk.DoubleVar(value=0.72)
        self.selection_steps_var = tk.DoubleVar(value=24)
        self.brush_size_var = tk.DoubleVar(value=14)
        self._scale_row(tools, 2, "智能容差", self.tolerance_var, 5, 90, 1)
        self._scale_row(tools, 3, "边缘保护", self.edge_protection_var, 0, 1, 0.05)
        self._scale_row(tools, 4, "传播次数", self.selection_steps_var, 6, 48, 1)
        self._scale_row(tools, 5, "画笔大小", self.brush_size_var, 2, 48, 1)
        ttk.Label(
            tools,
            text="左键按当前操作；右键临时执行相反操作。智能选区点击连通区域，快速选择涂抹样本，精细画笔自动吸附强反射边缘。",
            wraplength=310,
            foreground="#376f89",
        ).grid(row=6, column=0, columnspan=2, sticky="w", pady=(5, 0))

        refine = ttk.LabelFrame(controls, text="细致选择 / 边缘优化", padding=10)
        refine.pack(fill="x", pady=(0, 10))
        self.smooth_var = tk.DoubleVar(value=2)
        self.feather_var = tk.DoubleVar(value=2)
        self.contrast_var = tk.DoubleVar(value=0.25)
        self.shift_var = tk.DoubleVar(value=0)
        self.edge_snap_var = tk.DoubleVar(value=0.75)
        self._scale_row(refine, 0, "平滑", self.smooth_var, 0, 6, 1)
        self._scale_row(refine, 1, "羽化半径", self.feather_var, 0, 8, 1)
        self._scale_row(refine, 2, "边缘对比", self.contrast_var, 0, 1, 0.05)
        self._scale_row(refine, 3, "边界移动", self.shift_var, -8, 8, 1)
        self._scale_row(refine, 4, "反射边缘吸附", self.edge_snap_var, 0, 1, 0.05)
        self.refine_button = ttk.Button(refine, text="应用细致选择", command=self._apply_refine)
        self.refine_button.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(6, 2))
        edit_row = ttk.Frame(refine)
        edit_row.grid(row=6, column=0, columnspan=2, sticky="ew")
        ttk.Button(edit_row, text="撤销 Ctrl+Z", command=self._undo).pack(
            side="left", expand=True, fill="x", padx=(0, 3)
        )
        ttk.Button(edit_row, text="重做 Ctrl+Y", command=self._redo).pack(
            side="left", expand=True, fill="x", padx=(3, 0)
        )
        ttk.Button(refine, text="清空当前选区", command=self._clear_current).grid(
            row=7, column=0, columnspan=2, sticky="ew", pady=(4, 0)
        )

        display = ttk.LabelFrame(controls, text="显示与导出", padding=10)
        display.pack(fill="x", pady=(0, 10))
        self.opacity_var = tk.DoubleVar(value=0.32)
        self._scale_row(display, 0, "选区透明度", self.opacity_var, 0.05, 0.75, 0.05, self._render)
        self.only_annotated_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            display, text="只导出已有ROI的帧", variable=self.only_annotated_var
        ).grid(row=1, column=0, columnspan=2, sticky="w")
        self.export_button = ttk.Button(display, text="导出U-Net图像/掩膜数据集", command=self._export_dataset)
        self.export_button.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(5, 2))
        project_row = ttk.Frame(display)
        project_row.grid(row=3, column=0, columnspan=2, sticky="ew")
        ttk.Button(project_row, text="保存工程", command=self._save_project).pack(
            side="left", expand=True, fill="x", padx=(0, 3)
        )
        ttk.Button(project_row, text="载入工程", command=self._load_project).pack(
            side="left", expand=True, fill="x", padx=(3, 0)
        )

        training = ttk.LabelFrame(controls, text="U-Net训练与ONNX导出（可选）", padding=10)
        training.pack(fill="x", pady=(0, 10))
        self.train_epochs_var = tk.StringVar(value="30")
        self.train_batch_var = tk.StringVar(value="2")
        self.train_lr_var = tk.StringVar(value="0.001")
        self.train_size_var = tk.StringVar(value="512")
        self.train_model_var = tk.StringVar()
        for row, (label, variable) in enumerate(
            (
                ("训练轮数", self.train_epochs_var),
                ("批量大小", self.train_batch_var),
                ("学习率", self.train_lr_var),
                ("输入尺寸", self.train_size_var),
            )
        ):
            ttk.Label(training, text=label).grid(row=row, column=0, sticky="w", pady=2)
            ttk.Entry(training, textvariable=variable, width=14).grid(
                row=row, column=1, sticky="ew", pady=2
            )
        ttk.Label(training, text="输出ONNX").grid(row=4, column=0, sticky="w", pady=2)
        model_row = ttk.Frame(training)
        model_row.grid(row=4, column=1, sticky="ew", pady=2)
        ttk.Entry(model_row, textvariable=self.train_model_var).pack(
            side="left", expand=True, fill="x"
        )
        ttk.Button(model_row, text="浏览", width=6, command=self._browse_model_output).pack(
            side="left", padx=(4, 0)
        )
        self.train_button = ttk.Button(
            training,
            text="训练并导出 fetal_roi_unet.onnx",
            command=self._train_model,
        )
        self.train_button.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(6, 2))
        ttk.Label(
            training,
            text="先导出数据集，再安装训练组件。CPU可训练但较慢；有CUDA环境时PyTorch会自动使用GPU。",
            wraplength=310,
            foreground="#795b24",
        ).grid(row=6, column=0, columnspan=2, sticky="w", pady=(4, 0))

        self.status_var = tk.StringVar(value="就绪")
        ttk.Label(controls, textvariable=self.status_var, wraplength=315).pack(fill="x")
        self.progress = ttk.Progressbar(controls, mode="determinate")
        self.progress.pack(fill="x", pady=(4, 0))

        viewer = ttk.Frame(self, padding=(5, 10, 10, 10))
        viewer.grid(row=0, column=1, sticky="nsew")
        viewer.columnconfigure(0, weight=1)
        viewer.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(viewer, bg="#101215", highlightthickness=0, cursor="crosshair")
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.bind("<Configure>", self._render)
        self.canvas.bind("<Button-1>", lambda e: self._pointer_down(e, reverse=False))
        self.canvas.bind("<B1-Motion>", lambda e: self._pointer_drag(e, reverse=False))
        self.canvas.bind("<ButtonRelease-1>", self._pointer_up)
        self.canvas.bind("<Button-3>", lambda e: self._pointer_down(e, reverse=True))
        self.canvas.bind("<B3-Motion>", lambda e: self._pointer_drag(e, reverse=True))
        self.canvas.bind("<ButtonRelease-3>", self._pointer_up)
        navigation = ttk.Frame(viewer)
        navigation.grid(row=1, column=0, sticky="ew", pady=(7, 0))
        navigation.columnconfigure(2, weight=1)
        ttk.Button(navigation, text="上一帧", command=lambda: self._step_frame(-1)).grid(row=0, column=0)
        ttk.Button(navigation, text="下一帧", command=lambda: self._step_frame(1)).grid(row=0, column=1, padx=(5, 8))
        self.frame_var = tk.IntVar(value=1)
        self.frame_scale = ttk.Scale(navigation, from_=1, to=1, variable=self.frame_var, command=self._frame_changed)
        self.frame_scale.grid(row=0, column=2, sticky="ew")
        self.frame_label = ttk.Label(navigation, text="0 / 0")
        self.frame_label.grid(row=0, column=3, padx=(8, 0))
        self.bind("<Control-z>", lambda _e: self._undo())
        self.bind("<Control-y>", lambda _e: self._redo())

    @staticmethod
    def _path_row(parent, label, variable, command):
        ttk.Label(parent, text=label).pack(anchor="w")
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=(2, 5))
        ttk.Entry(row, textvariable=variable).pack(side="left", expand=True, fill="x")
        ttk.Button(row, text="浏览", width=7, command=command).pack(side="left", padx=(5, 0))

    @staticmethod
    def _scale_row(parent, row, label, variable, minimum, maximum, resolution, command=None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w")
        tk.Scale(
            parent,
            from_=minimum,
            to=maximum,
            resolution=resolution,
            variable=variable,
            orient=tk.HORIZONTAL,
            showvalue=True,
            length=190,
            command=command,
            highlightthickness=0,
        ).grid(row=row, column=1, sticky="ew")

    def _browse_source(self):
        name = filedialog.askdirectory(title="选择采集目录或图片目录")
        if name:
            self.source_var.set(name)
            if not self.output_var.get():
                self.output_var.set(str(Path(name) / "fetal_roi_dataset"))

    def _browse_output(self):
        name = filedialog.askdirectory(title="选择U-Net数据集输出目录")
        if name:
            self.output_var.set(name)
            if not self.train_model_var.get():
                self.train_model_var.set(str(Path(name) / "models" / "fetal_roi_unet.onnx"))

    def _browse_model_output(self):
        name = filedialog.asksaveasfilename(
            title="选择U-Net ONNX输出文件",
            defaultextension=".onnx",
            filetypes=(("ONNX模型", "*.onnx"),),
        )
        if name:
            self.train_model_var.set(name)

    def _set_busy(self, busy: bool):
        self.busy = busy
        state = "disabled" if busy else "normal"
        for button in (
            self.load_capture_button,
            self.load_images_button,
            self.refine_button,
            self.export_button,
            self.train_button,
        ):
            button.configure(state=state)
        if not busy:
            self.progress["value"] = 0

    def _run_task(self, target):
        self._set_busy(True)
        threading.Thread(target=target, daemon=True).start()

    def _load_capture(self):
        folder = Path(self.source_var.get())

        def task():
            try:
                info = read_capture_metadata(folder)
                p = ProcessParams(
                    width=info["sampleCount"],
                    height=info["lineCount"],
                    frame_count=info["frameCount"],
                    dsc_enabled=True,
                    dsc_angle_deg=info["scanAngleDeg"],
                    dsc_inner_radius=info["deadRadius"],
                    dsc_output_width=info["suggestedDscWidth"],
                    dsc_output_height=info["suggestedDscHeight"],
                )
                raw = read_frames(Path(info["rawFile"]), p)
                frames = dsc_scan_convert(
                    raw,
                    p,
                    lambda x, s: self.task_queue.put(("progress", x, s)),
                )
                names = [f"frame_{i + 1:04d}.png" for i in range(len(frames))]
                self.task_queue.put(("loaded", [x for x in frames], names, info))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))

        self.status_var.set("正在读取采集目录并执行DSC…")
        self._run_task(task)

    def _load_images(self):
        folder = Path(self.source_var.get())

        def task():
            try:
                paths = sorted(p for p in folder.iterdir() if p.suffix.lower() in IMAGE_SUFFIXES)
                if not paths:
                    raise ValueError("所选目录中没有支持的图片。")
                frames = [np.asarray(Image.open(p).convert("L"), dtype=np.uint8) for p in paths]
                self.task_queue.put(("loaded", frames, [p.name for p in paths], {"source": str(folder)}))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))

        self.status_var.set("正在读取图片目录…")
        self._run_task(task)

    def _install_frames(self, frames, names, metadata):
        self.frames = frames
        self.source_names = names
        self.capture_metadata = metadata
        self.masks = [np.zeros(frame.shape, dtype=bool) for frame in frames]
        self.undo_stacks = [[] for _ in frames]
        self.redo_stacks = [[] for _ in frames]
        self.gradient_cache = [None for _ in frames]
        self.current_index = 0
        self.frame_scale.configure(to=max(1, len(frames)))
        self.frame_var.set(1)
        self.dataset_var.set(f"已载入 {len(frames)} 帧｜尺寸 {frames[0].shape[1]}×{frames[0].shape[0]}")
        self._new_scribbles()
        self._update_frame_label()
        self._render()

    def _new_scribbles(self):
        if not self.frames:
            self.positive_scribble = None
            self.negative_scribble = None
            return
        shape = self.frames[self.current_index].shape
        self.positive_scribble = np.zeros(shape, dtype=bool)
        self.negative_scribble = np.zeros(shape, dtype=bool)

    def _frame_changed(self, _value=None):
        if not self.frames:
            return
        self.current_index = max(0, min(len(self.frames) - 1, round(float(self.frame_var.get())) - 1))
        self._new_scribbles()
        self._update_frame_label()
        self._render()

    def _step_frame(self, delta):
        if self.frames:
            self.frame_var.set(max(1, min(len(self.frames), self.current_index + 1 + delta)))
            self._frame_changed()

    def _update_frame_label(self):
        if not self.frames:
            self.frame_label.configure(text="0 / 0")
            return
        annotated = sum(bool(np.any(mask)) for mask in self.masks)
        self.frame_label.configure(text=f"{self.current_index + 1} / {len(self.frames)}｜已标 {annotated}")

    def _render(self, _event=None):
        if not self.frames:
            self.canvas.delete("all")
            self.canvas.create_text(20, 20, anchor="nw", fill="#d0d5da", text="请选择采集目录或图片目录")
            return
        frame = self.frames[self.current_index]
        mask = self.masks[self.current_index]
        shown = overlay_selection(
            frame,
            mask,
            self.positive_scribble,
            self.negative_scribble,
            self.opacity_var.get(),
        )
        width = max(100, self.canvas.winfo_width())
        height = max(100, self.canvas.winfo_height())
        scale = min((width - 20) / frame.shape[1], (height - 20) / frame.shape[0])
        size = (max(1, round(frame.shape[1] * scale)), max(1, round(frame.shape[0] * scale)))
        image = Image.fromarray(shown).resize(size, Image.Resampling.LANCZOS)
        self.display_photo = ImageTk.PhotoImage(image)
        x0, y0 = (width - size[0]) / 2.0, (height - size[1]) / 2.0
        self.display_scale = scale
        self.display_offset = (x0, y0)
        self.canvas.delete("all")
        self.canvas.create_image(x0, y0, anchor="nw", image=self.display_photo)

    def _event_point(self, event):
        if not self.frames:
            return None
        x = int(round((event.x - self.display_offset[0]) / max(self.display_scale, 1e-8)))
        y = int(round((event.y - self.display_offset[1]) / max(self.display_scale, 1e-8)))
        frame = self.frames[self.current_index]
        if 0 <= x < frame.shape[1] and 0 <= y < frame.shape[0]:
            return x, y
        return None

    def _push_undo(self):
        stack = self.undo_stacks[self.current_index]
        stack.append(self.masks[self.current_index].copy())
        if len(stack) > 30:
            del stack[0]
        self.redo_stacks[self.current_index].clear()

    def _pointer_down(self, event, reverse: bool):
        if self.busy:
            return
        point = self._event_point(event)
        if point is None:
            return
        self.stroke_active = True
        self.stroke_changed = False
        self._push_undo()
        self._apply_pointer(point[0], point[1], reverse)

    def _pointer_drag(self, event, reverse: bool):
        if not self.stroke_active:
            return
        point = self._event_point(event)
        if point is not None:
            self._apply_pointer(point[0], point[1], reverse)

    def _pointer_up(self, _event):
        if not self.stroke_active:
            return
        self.stroke_active = False
        if self.tool_var.get() == "快速选择" and self.stroke_changed:
            self.masks[self.current_index] = quick_selection(
                self.frames[self.current_index],
                self.masks[self.current_index],
                self.positive_scribble,
                self.negative_scribble,
                self.edge_protection_var.get(),
                int(round(self.selection_steps_var.get())),
            )
            self._new_scribbles()
        if not self.stroke_changed and self.undo_stacks[self.current_index]:
            self.undo_stacks[self.current_index].pop()
        self._update_frame_label()
        self._render()

    def _effective_add(self, reverse: bool) -> bool:
        add = self.operation_var.get() == "加选"
        return not add if reverse else add

    def _apply_pointer(self, x: int, y: int, reverse: bool):
        frame = self.frames[self.current_index]
        add = self._effective_add(reverse)
        tool = self.tool_var.get()
        if tool == "智能选区":
            region = smart_wand_region(
                frame,
                x,
                y,
                self.tolerance_var.get(),
                self.edge_protection_var.get(),
                int(round(self.selection_steps_var.get())),
            )
            if add:
                self.masks[self.current_index] |= region
            else:
                self.masks[self.current_index] &= ~region
            self.stroke_changed = bool(np.any(region))
            self.stroke_active = False
            self._update_frame_label()
        elif tool == "快速选择":
            radius = max(1, round(self.brush_size_var.get() / max(self.display_scale, 0.2)))
            brush = disk_mask(frame.shape, x, y, radius)
            if add:
                self.positive_scribble |= brush
                self.negative_scribble &= ~brush
            else:
                self.negative_scribble |= brush
                self.positive_scribble &= ~brush
            self.stroke_changed = True
        else:
            radius = max(1, round(self.brush_size_var.get() / max(self.display_scale, 0.2)))
            gradient = self.gradient_cache[self.current_index]
            if gradient is None:
                gradient = gradient_map(frame)
                self.gradient_cache[self.current_index] = gradient
            search = max(2, radius // 2)
            y0, y1 = max(0, y - search), min(frame.shape[0], y + search + 1)
            x0, x1 = max(0, x - search), min(frame.shape[1], x + search + 1)
            local = gradient[y0:y1, x0:x1]
            if local.size:
                yy, xx = np.unravel_index(int(np.argmax(local)), local.shape)
                y, x = y0 + int(yy), x0 + int(xx)
            brush = disk_mask(frame.shape, x, y, radius)
            if add:
                self.masks[self.current_index] |= brush
            else:
                self.masks[self.current_index] &= ~brush
            self.stroke_changed = True
        self._render()

    def _apply_refine(self):
        if not self.frames or not np.any(self.masks[self.current_index]):
            return
        self._push_undo()
        self.masks[self.current_index] = refine_selection(
            self.frames[self.current_index],
            self.masks[self.current_index],
            int(round(self.smooth_var.get())),
            int(round(self.feather_var.get())),
            self.contrast_var.get(),
            int(round(self.shift_var.get())),
            self.edge_snap_var.get(),
        )
        self._update_frame_label()
        self._render()

    def _clear_current(self):
        if self.frames and np.any(self.masks[self.current_index]):
            self._push_undo()
            self.masks[self.current_index][:] = False
            self._new_scribbles()
            self._update_frame_label()
            self._render()

    def _undo(self):
        if not self.frames or not self.undo_stacks[self.current_index]:
            return
        self.redo_stacks[self.current_index].append(self.masks[self.current_index].copy())
        self.masks[self.current_index] = self.undo_stacks[self.current_index].pop()
        self._update_frame_label()
        self._render()

    def _redo(self):
        if not self.frames or not self.redo_stacks[self.current_index]:
            return
        self.undo_stacks[self.current_index].append(self.masks[self.current_index].copy())
        self.masks[self.current_index] = self.redo_stacks[self.current_index].pop()
        self._update_frame_label()
        self._render()

    def _export_dataset(self):
        if not self.frames:
            messagebox.showinfo(APP_TITLE, "请先载入图像。")
            return
        root_text = self.output_var.get().strip()
        if not root_text:
            messagebox.showinfo(APP_TITLE, "请选择输出目录。")
            return
        root = Path(root_text)
        only_annotated = self.only_annotated_var.get()

        def task():
            try:
                images_dir = root / "images"
                masks_dir = root / "masks"
                overlays_dir = root / "overlays"
                images_dir.mkdir(parents=True, exist_ok=True)
                masks_dir.mkdir(parents=True, exist_ok=True)
                overlays_dir.mkdir(parents=True, exist_ok=True)
                items = []
                candidates = [i for i, mask in enumerate(self.masks) if np.any(mask) or not only_annotated]
                if not candidates:
                    raise ValueError("当前没有已标注的胎儿ROI。")
                for done, index in enumerate(candidates, 1):
                    name = f"frame_{index + 1:04d}.png"
                    Image.fromarray(self.frames[index], mode="L").save(images_dir / name)
                    Image.fromarray(self.masks[index].astype(np.uint8) * 255, mode="L").save(masks_dir / name)
                    preview = overlay_selection(self.frames[index], self.masks[index], None, None, 0.32)
                    Image.fromarray(preview).save(overlays_dir / name)
                    items.append(
                        {
                            "frame": index + 1,
                            "source_name": self.source_names[index],
                            "image": f"images/{name}",
                            "mask": f"masks/{name}",
                            "roi_fraction": float(self.masks[index].mean()),
                        }
                    )
                    self.task_queue.put(("progress", done / len(candidates), f"正在导出 {done}/{len(candidates)}"))
                if len(items) >= 5:
                    validation = [item for position, item in enumerate(items) if (position + 1) % 5 == 0]
                    training = [item for position, item in enumerate(items) if (position + 1) % 5 != 0]
                elif len(items) >= 2:
                    validation = [items[-1]]
                    training = items[:-1]
                else:
                    validation = []
                    training = items
                pair_line = lambda item: f'{item["image"]} {item["mask"]}'
                (root / "train.txt").write_text(
                    "\n".join(pair_line(item) for item in training), encoding="utf-8"
                )
                (root / "val.txt").write_text(
                    "\n".join(pair_line(item) for item in validation), encoding="utf-8"
                )
                manifest = {
                    "format": "binary fetal ROI segmentation",
                    "image_encoding": "uint8 grayscale PNG",
                    "mask_encoding": "0 background, 255 fetal ROI",
                    "annotated_frame_count": len(items),
                    "train_count": len(training),
                    "validation_count": len(validation),
                    "capture_metadata": self.capture_metadata,
                    "items": items,
                }
                (root / "dataset.json").write_text(
                    json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
                )
                self.task_queue.put(("exported", root, len(items)))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))

        self.status_var.set("正在导出U-Net训练数据集…")
        self._run_task(task)

    def _train_model(self):
        dataset = Path(self.output_var.get().strip())
        try:
            if not (dataset / "train.txt").is_file():
                raise ValueError("请先导出U-Net图像/掩膜数据集。")
            epochs = int(self.train_epochs_var.get())
            batch = int(self.train_batch_var.get())
            learning_rate = float(self.train_lr_var.get())
            size = int(self.train_size_var.get())
            model_output = Path(self.train_model_var.get().strip())
            if not model_output.name:
                raise ValueError("请选择ONNX模型输出位置。")
            if model_output.suffix.lower() != ".onnx":
                model_output = model_output.with_suffix(".onnx")
            if not 1 <= epochs <= 1000 or not 1 <= batch <= 64:
                raise ValueError("训练轮数或批量大小超出合理范围。")
            if size < 128 or size > 1024 or size % 16:
                raise ValueError("输入尺寸必须是128–1024之间、且能被16整除。")
            if learning_rate <= 0:
                raise ValueError("学习率必须大于0。")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return
        script = Path(__file__).with_name("train_unet.py")

        def task():
            try:
                model_output.parent.mkdir(parents=True, exist_ok=True)
                command = [
                    sys.executable,
                    str(script),
                    "--dataset",
                    str(dataset),
                    "--output",
                    str(model_output),
                    "--epochs",
                    str(epochs),
                    "--batch",
                    str(batch),
                    "--lr",
                    str(learning_rate),
                    "--size",
                    str(size),
                ]
                process = subprocess.Popen(
                    command,
                    cwd=str(script.parent),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                recent = []
                assert process.stdout is not None
                for line in process.stdout:
                    line = line.strip()
                    if not line:
                        continue
                    recent.append(line)
                    recent = recent[-8:]
                    if line.startswith("PROGRESS "):
                        token = line.split()[1]
                        current, total = token.split("/", 1)
                        self.task_queue.put(
                            (
                                "progress",
                                int(current) / max(int(total), 1),
                                "U-Net训练：" + line,
                            )
                        )
                    else:
                        self.task_queue.put(("training_status", line))
                return_code = process.wait()
                if return_code != 0:
                    raise RuntimeError("U-Net训练失败：\n" + "\n".join(recent))
                self.task_queue.put(("training_done", model_output))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))

        self.status_var.set("正在启动U-Net训练…")
        self._run_task(task)

    def _save_project(self):
        if not self.frames:
            return
        path = filedialog.asksaveasfilename(
            title="保存ROI标注工程",
            defaultextension=".npz",
            filetypes=(("ROI工程", "*.npz"),),
        )
        if not path:
            return
        try:
            shapes = {frame.shape for frame in self.frames}
            if len(shapes) != 1:
                raise ValueError("图片尺寸不一致时不能保存单文件工程；请直接导出数据集。")
            np.savez_compressed(
                path,
                masks=np.stack(self.masks).astype(np.uint8),
                source_names=np.asarray(self.source_names),
            )
            self.status_var.set(f"工程已保存：{path}")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))

    def _load_project(self):
        if not self.frames:
            messagebox.showinfo(APP_TITLE, "请先载入与工程对应的图像。")
            return
        path = filedialog.askopenfilename(
            title="载入ROI标注工程", filetypes=(("ROI工程", "*.npz"),)
        )
        if not path:
            return
        try:
            with np.load(path, allow_pickle=False) as data:
                masks = data["masks"].astype(bool)
            if len(masks) != len(self.frames):
                raise ValueError("工程帧数与当前图像序列不一致。")
            for index, (mask, frame) in enumerate(zip(masks, self.frames)):
                if mask.shape != frame.shape:
                    raise ValueError(f"工程第{index + 1}帧尺寸不一致。")
            self.masks = [mask.copy() for mask in masks]
            self.undo_stacks = [[] for _ in self.frames]
            self.redo_stacks = [[] for _ in self.frames]
            self._new_scribbles()
            self._update_frame_label()
            self._render()
            self.status_var.set(f"工程已载入：{path}")
        except Exception as exc:
            messagebox.showerror(APP_TITLE, str(exc))

    def _poll_queue(self):
        try:
            while True:
                item = self.task_queue.get_nowait()
                if item[0] == "progress":
                    self.progress["value"] = float(item[1]) * 100.0
                    self.status_var.set(item[2])
                elif item[0] == "loaded":
                    self._set_busy(False)
                    self._install_frames(item[1], item[2], item[3])
                    self.status_var.set("图像已载入；可以开始胎儿ROI标注。")
                elif item[0] == "exported":
                    self._set_busy(False)
                    if not self.train_model_var.get():
                        self.train_model_var.set(
                            str(Path(item[1]) / "models" / "fetal_roi_unet.onnx")
                        )
                    self.status_var.set(f"已导出 {item[2]} 帧到 {item[1]}")
                    messagebox.showinfo(APP_TITLE, f"U-Net数据集导出完成：\n{item[1]}")
                elif item[0] == "training_status":
                    self.status_var.set(item[1])
                elif item[0] == "training_done":
                    self._set_busy(False)
                    self.status_var.set(f"U-Net训练完成：{item[1]}")
                    messagebox.showinfo(
                        APP_TITLE,
                        f"U-Net模型训练并导出完成：\n{item[1]}\n\n"
                        "可在Image v24中加载该ONNX模型。",
                    )
                elif item[0] == "error":
                    self._set_busy(False)
                    self.status_var.set("操作失败。")
                    messagebox.showerror(APP_TITLE, item[1])
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    FetalRoiAnnotator().mainloop()
