"""Bright, brightness-coherent regions with stable IDs across adjacent frames.

The input is the v31-corrected sequence.  A coarse graph makes whole-group
analysis practical without SciPy: spatial edges respect the v31 directional
edge response, and each node links to its best brightness match in the next
frame.  Components must occupy several frames before they are displayed.
"""

from __future__ import annotations

import colorsys
import math
from typing import Callable

import numpy as np
from PIL import Image, ImageFilter

from adaptive_edge_v30 import prepare_adaptive_edge_response


def region_color(region_id: int) -> tuple[int, int, int]:
    """Return a reproducible, high-saturation color for a persistent label."""
    if region_id < 1:
        raise ValueError("Region IDs begin at one")
    hue = (0.10 + (region_id - 1) * 0.61803398875) % 1.0
    rgb = colorsys.hsv_to_rgb(hue, 0.87, 1.0)
    return tuple(round(channel * 255) for channel in rgb)


def _scan_interior(frame: np.ndarray) -> np.ndarray:
    """Keep the scan footprint but not the black canvas or outer flare band."""
    active = frame > 0
    footprint = np.zeros_like(active)
    for row in range(frame.shape[0]):
        columns = np.flatnonzero(active[row])
        if columns.size:
            footprint[row, columns[0]:columns[-1] + 1] = True
    safe = footprint
    margin = max(1, round(min(frame.shape) * 0.015))
    for _ in range(margin):
        inner = np.zeros_like(safe)
        inner[1:-1, 1:-1] = (
            safe[1:-1, 1:-1] & safe[:-2, 1:-1] & safe[2:, 1:-1]
            & safe[1:-1, :-2] & safe[1:-1, 2:]
        )
        safe = inner
    return safe & (frame >= 8)


def _union_find_nodes(luma: np.ndarray, valid: np.ndarray, tolerance: float):
    count = luma.size
    parent = np.arange(count, dtype=np.int32)
    size = np.ones(count, dtype=np.int32)
    minimum = luma.ravel().copy()
    maximum = luma.ravel().copy()
    allowed_range = min(255.0, float(tolerance) * 2.0)

    def find(node: int) -> int:
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = int(parent[node])
        return node

    def join(a: int, b: int) -> None:
        root_a, root_b = find(a), find(b)
        if root_a == root_b:
            return
        low = min(int(minimum[root_a]), int(minimum[root_b]))
        high = max(int(maximum[root_a]), int(maximum[root_b]))
        if high - low > allowed_range:
            return
        if size[root_a] < size[root_b]:
            root_a, root_b = root_b, root_a
        parent[root_b] = root_a
        size[root_a] += size[root_b]
        minimum[root_a] = low
        maximum[root_a] = high

    return parent, find, join


def segment_temporal_regions(
    frames: np.ndarray,
    *,
    bright_threshold: float = 150.0,
    brightness_tolerance: float = 35.0,
    gradient_limit: float = 55.0,
    min_frames: int = 3,
    cell_size: int = 8,
    max_regions: int = 24,
    min_area_pixels: int = 128,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, dict]:
    """Label persistent bright areas of similar intensity in a uint8 sequence.

    Label zero is unselected.  Positive IDs refer to the same connected
    region in every frame, not merely to the same brightness class.  The
    returned labels are full resolution; graph decisions are made on square
    cells of roughly ``cell_size`` source pixels for speed.
    """
    if frames.ndim != 3 or frames.dtype != np.uint8 or not len(frames):
        raise ValueError("需要非空的 [帧, 高, 宽] uint8 灰度序列。")
    if not 4 <= cell_size <= 16:
        raise ValueError("区域网格大小应在 4–16 像素之间。")
    if not 100 <= bright_threshold <= 240:
        raise ValueError("高亮区域下限应在 100–240 灰阶之间。")
    if not 4 <= brightness_tolerance <= 80 or not 8 <= gradient_limit <= 120:
        raise ValueError("亮度相似度或梯度阻断阈值超出范围。")
    if not 2 <= min_frames <= len(frames):
        raise ValueError("最少连续帧数应在 2 和实际帧数之间。")
    if not 1 <= max_regions <= 32:
        raise ValueError("区域数量应在 1–32 之间。")
    if not 16 <= min_area_pixels <= 100000:
        raise ValueError("最小区域面积应在 16–100000 像素之间。")

    frame_count, height, width = frames.shape
    grid_h = math.ceil(height / cell_size)
    grid_w = math.ceil(width / cell_size)
    nodes_per_frame = grid_h * grid_w
    node_count = frame_count * nodes_per_frame
    if node_count > 2_000_000:
        raise ValueError("区域网格过大；请增大网格大小以控制内存和处理时间。")

    luma = np.empty((frame_count, grid_h, grid_w), dtype=np.uint8)
    valid = np.empty_like(luma, dtype=bool)
    response = np.empty_like(luma, dtype=np.float32)
    for index, frame in enumerate(frames):
        coarse = np.asarray(
            Image.fromarray(frame, mode="L").resize(
                (grid_w, grid_h), Image.Resampling.BOX
            )
        )
        # A small median in graph space suppresses isolated speckle without
        # modifying the exported image or washing out a step boundary.
        luma[index] = np.asarray(
            Image.fromarray(coarse, mode="L").filter(ImageFilter.MedianFilter(3))
        )
        valid[index] = _scan_interior(coarse) & (luma[index] >= bright_threshold)
        # This is the same directional, halo-limited edge response used by v31.
        response[index] = np.abs(prepare_adaptive_edge_response(luma[index]))
        if progress and (index % 8 == 0 or index + 1 == frame_count):
            progress(0.22 * (index + 1) / frame_count,
                     f"正在计算亮度和 v31 边缘 {index + 1}/{frame_count} 帧")

    parent, find, join = _union_find_nodes(luma, valid, brightness_tolerance)
    node_ids = np.arange(node_count, dtype=np.int32).reshape(luma.shape)

    # Spatial edges: local brightness must match, and the gradient plus v31
    # directional response must stay below the explicit boundary threshold.
    for index in range(frame_count):
        for first, second, first_id, second_id, first_valid, second_valid, first_response, second_response in (
            (luma[index, :, :-1], luma[index, :, 1:],
             node_ids[index, :, :-1], node_ids[index, :, 1:],
             valid[index, :, :-1], valid[index, :, 1:],
             response[index, :, :-1], response[index, :, 1:]),
            (luma[index, :-1, :], luma[index, 1:, :],
             node_ids[index, :-1, :], node_ids[index, 1:, :],
             valid[index, :-1, :], valid[index, 1:, :],
             response[index, :-1, :], response[index, 1:, :]),
        ):
            difference = np.abs(first.astype(np.int16) - second.astype(np.int16))
            barrier = difference + 0.9 * np.maximum(first_response, second_response)
            allowed = (first_valid & second_valid
                       & (difference <= brightness_tolerance)
                       & (barrier <= gradient_limit))
            for a, b in zip(first_id[allowed], second_id[allowed]):
                join(int(a), int(b))
        if progress and (index % 8 == 0 or index + 1 == frame_count):
            progress(0.22 + 0.38 * (index + 1) / frame_count,
                     f"正在连接单帧区域 {index + 1}/{frame_count}")

    # Each cell can attach only to its best match in the next frame.  A one-
    # cell displacement accommodates modest motion without making all equally
    # bright tissues in the frame one region.
    for index in range(frame_count - 1):
        best_difference = np.full((grid_h, grid_w), 1000, dtype=np.int16)
        best_neighbor = np.full((grid_h, grid_w), -1, dtype=np.int32)
        for dy, dx in ((0, 0), (0, 1), (0, -1), (1, 0), (-1, 0)):
            source_y = slice(max(0, -dy), min(grid_h, grid_h - dy))
            source_x = slice(max(0, -dx), min(grid_w, grid_w - dx))
            target_y = slice(max(0, dy), min(grid_h, grid_h + dy))
            target_x = slice(max(0, dx), min(grid_w, grid_w + dx))
            first = luma[index, source_y, source_x]
            second = luma[index + 1, target_y, target_x]
            difference = np.abs(first.astype(np.int16) - second.astype(np.int16))
            barrier = difference + 0.5 * np.maximum(
                response[index, source_y, source_x],
                response[index + 1, target_y, target_x],
            )
            best_view = best_difference[source_y, source_x]
            allowed = (valid[index, source_y, source_x]
                       & valid[index + 1, target_y, target_x]
                       & (difference <= brightness_tolerance)
                       & (barrier <= gradient_limit)
                       & (difference < best_view))
            best_view[allowed] = difference[allowed]
            best_neighbor[source_y, source_x][allowed] = node_ids[
                index + 1, target_y, target_x
            ][allowed]
        chosen = best_neighbor >= 0
        for a, b in zip(node_ids[index][chosen], best_neighbor[chosen]):
            join(int(a), int(b))
        if progress and (index % 8 == 0 or index + 2 == frame_count):
            progress(0.60 + 0.30 * (index + 1) / max(frame_count - 1, 1),
                     f"正在匹配相邻帧 {index + 1}/{frame_count - 1}")

    flat_valid = np.flatnonzero(valid.ravel())
    root_valid = np.fromiter((find(int(node)) for node in flat_valid),
                             dtype=np.int32, count=len(flat_valid))
    total_cells = np.bincount(root_valid, minlength=node_count)
    frame_index = flat_valid // nodes_per_frame
    pair_key = root_valid.astype(np.int64) * frame_count + frame_index
    unique_pair, cells_per_frame = np.unique(pair_key, return_counts=True)
    root_per_pair = unique_pair // frame_count
    minimum_cells = max(1, math.ceil(min_area_pixels / (cell_size * cell_size)))
    supported_frames = np.bincount(
        root_per_pair[cells_per_frame >= minimum_cells], minlength=node_count,
    )
    candidates = np.flatnonzero(
        (supported_frames >= min_frames)
        & (total_cells >= minimum_cells * min_frames)
    )
    # Require a run of consecutive supported frames.  An area that appears
    # briefly, disappears, and reappears later does not meet the temporal rule.
    persistent = []
    for root in candidates:
        start = np.searchsorted(root_per_pair, root, side="left")
        end = np.searchsorted(root_per_pair, root, side="right")
        nearby_frames = unique_pair[start:end][
            cells_per_frame[start:end] >= minimum_cells
        ] % frame_count
        run = best_run = 1
        for gap in np.diff(nearby_frames):
            run = run + 1 if gap == 1 else 1
            best_run = max(best_run, run)
        if best_run >= min_frames:
            persistent.append(root)
    candidates = np.asarray(persistent, dtype=np.int32)
    if candidates.size:
        score = total_cells[candidates] * np.sqrt(supported_frames[candidates])
        selected = candidates[np.argsort(score)[::-1][:max_regions]]
    else:
        selected = np.empty(0, dtype=np.int32)

    root_to_label = np.zeros(node_count, dtype=np.uint16)
    root_to_label[selected] = np.arange(1, len(selected) + 1, dtype=np.uint16)
    low_labels = np.zeros(node_count, dtype=np.uint16)
    low_labels[flat_valid] = root_to_label[root_valid]
    low_labels = low_labels.reshape(luma.shape)
    labels = np.empty(frames.shape, dtype=np.uint16)
    for index in range(frame_count):
        labels[index] = np.asarray(
            Image.fromarray(low_labels[index].astype(np.int32), mode="I").resize(
                (width, height), Image.Resampling.NEAREST
            ), dtype=np.uint16,
        )
        # A bright coarse cell can contain individual dark pixels.  They must
        # not inherit its color just because nearest-neighbor upsampling did.
        labels[index][frames[index] < bright_threshold] = 0
        if progress and (index % 8 == 0 or index + 1 == frame_count):
            progress(0.90 + 0.10 * (index + 1) / frame_count,
                     f"正在生成彩色区域 {index + 1}/{frame_count} 帧")

    brightness_sum = np.bincount(
        root_valid, weights=luma.ravel()[flat_valid], minlength=node_count,
    )
    regions = []
    for label, root in enumerate(selected, start=1):
        pair_mask = (root_per_pair == root) & (cells_per_frame >= minimum_cells)
        frames_present = (unique_pair[pair_mask] % frame_count + 1).tolist()
        regions.append({
            "id": label,
            "color_rgb": list(region_color(label)),
            "mean_gray_level": round(float(brightness_sum[root] / total_cells[root]), 2),
            "coarse_cell_count": int(total_cells[root]),
            "supported_frames_one_based": frames_present,
        })
    return labels, {
        "algorithm": "thresholded bright cells with v31 directional-gradient-barrier spatiotemporal graph components",
        "bright_threshold_gray_level": float(bright_threshold),
        "brightness_tolerance": float(brightness_tolerance),
        "gradient_limit": float(gradient_limit),
        "minimum_supported_frames": int(min_frames),
        "minimum_area_pixels_per_supported_frame": int(min_area_pixels),
        "cell_size_pixels": int(cell_size),
        "coarse_shape": list(luma.shape),
        "output_shape": list(labels.shape),
        "region_count": len(regions),
        "regions": regions,
        "note": "Brightness/edge-connected regions are display labels, not anatomical segmentation or diagnosis.",
    }


def add_region_overlay(
    image: np.ndarray, labels: np.ndarray, alpha: float = 0.36,
) -> np.ndarray:
    """Blend vivid stable region colors, leaving prior red/blue lines legible."""
    if labels.ndim != 2 or image.shape[:2] != labels.shape:
        raise ValueError("区域标签与当前图像的尺寸不一致。")
    if not 0.0 <= alpha <= 1.0:
        raise ValueError("颜色透明度应在 0–1 之间。")
    rgb = (
        np.repeat(image[..., None], 3, axis=2)
        if image.ndim == 2 else image.copy()
    )
    original_gray = (rgb[..., 0] == rgb[..., 1]) & (rgb[..., 1] == rgb[..., 2])
    for label in np.unique(labels):
        if label == 0:
            continue
        color = np.asarray(region_color(int(label)), dtype=np.float32)
        region = labels == label
        interior = region & original_gray
        rgb[interior] = np.rint(
            (1.0 - alpha) * rgb[interior].astype(np.float32) + alpha * color
        ).astype(np.uint8)
        eroded = np.zeros_like(region)
        eroded[1:-1, 1:-1] = (
            region[1:-1, 1:-1] & region[:-2, 1:-1] & region[2:, 1:-1]
            & region[1:-1, :-2] & region[1:-1, 2:]
        )
        rgb[region & ~eroded & original_gray] = color.astype(np.uint8)
    return rgb
