"""Focused checks for persistent high-brightness regions and v31 compatibility."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from temporal_regions_v32 import add_region_overlay, region_color, segment_temporal_regions
from ultrasound_bin_gui import ProcessParams, export_results, process_frames


class V32Tests(unittest.TestCase):
    @staticmethod
    def moving_regions() -> np.ndarray:
        frames = np.zeros((5, 96, 96), dtype=np.uint8)
        frames[:, 8:88, 8:88] = 30
        for index in range(5):
            frames[index, 25:53, 20 + index:48 + index] = 150
        frames[:, 58:78, 58:78] = 190
        frames[:, 11:23, 55:78] = 100  # Persistent dark patch stays unlabeled.
        frames[2, 60:72, 24:36] = 205  # One-frame speckle must not persist.
        return frames

    def test_same_moving_area_keeps_its_id_across_frames(self):
        labels, report = segment_temporal_regions(
            self.moving_regions(), cell_size=4, min_area_pixels=64,
            min_frames=3, max_regions=10,
        )
        moving_ids = [int(labels[i, 38, 34 + i]) for i in range(5)]
        second_ids = [int(labels[i, 66, 66]) for i in range(5)]
        self.assertEqual(len(set(moving_ids)), 1)
        self.assertEqual(len(set(second_ids)), 1)
        self.assertGreater(moving_ids[0], 0)
        self.assertGreater(second_ids[0], 0)
        self.assertNotEqual(moving_ids[0], second_ids[0])
        self.assertEqual(int(labels[2, 66, 28]), 0)
        self.assertTrue(np.all(labels[:, 15, 62] == 0))
        self.assertTrue(np.all(labels[self.moving_regions() < 150] == 0))
        self.assertGreaterEqual(report["region_count"], 2)
        self.assertEqual(report["bright_threshold_gray_level"], 150.0)

    def test_uniform_dark_sequence_has_no_regions(self):
        frames = np.zeros((4, 80, 80), dtype=np.uint8)
        frames[:, 8:72, 8:72] = 110
        labels, report = segment_temporal_regions(frames, cell_size=4)
        self.assertEqual(int(labels.max()), 0)
        self.assertEqual(report["region_count"], 0)

    def test_vivid_overlay_preserves_existing_red_blue_lines(self):
        image = np.full((24, 24, 3), 100, dtype=np.uint8)
        image[5, 5] = (255, 32, 32)
        image[6, 6] = (32, 112, 255)
        labels = np.zeros((24, 24), dtype=np.uint16)
        labels[3:15, 3:15] = 1
        labels[15:22, 15:22] = 2
        output = add_region_overlay(image, labels)
        np.testing.assert_array_equal(output[5, 5], image[5, 5])
        np.testing.assert_array_equal(output[6, 6], image[6, 6])
        self.assertEqual(tuple(output[3, 3]), region_color(1))
        self.assertEqual(tuple(output[15, 15]), region_color(2))
        self.assertNotEqual(region_color(1), region_color(2))

    def test_export_keeps_grayscale_and_writes_recoverable_labels(self):
        raw = self.moving_regions()[:3]
        params = ProcessParams(width=96, height=96, region_enabled=True)
        processed, meta = process_frames(raw, params)
        labels, report = segment_temporal_regions(
            processed, cell_size=4, min_area_pixels=64, min_frames=2,
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            bin_path, png_dir, comparison = export_results(
                Path("raw_frames_u8.bin"), root, raw, processed, meta, params,
                region_labels=labels, region_report=report,
            )
            np.testing.assert_array_equal(
                np.fromfile(bin_path, dtype=np.uint8).reshape(processed.shape),
                processed,
            )
            label_binary = root / "raw_frames_u8_region_labels_u16.bin"
            np.testing.assert_array_equal(
                np.fromfile(label_binary, dtype=np.uint16).reshape(labels.shape),
                labels,
            )
            with Image.open(root / "raw_frames_u8_region_labels" / "region_0001.png") as png:
                np.testing.assert_array_equal(np.asarray(png), labels[0])
            with Image.open(png_dir / "frame_0001.png") as png:
                self.assertEqual(png.mode, "RGB")
            with Image.open(comparison) as png:
                self.assertEqual(png.width, 1024)
            data = json.loads((root / "raw_frames_u8_processing.json").read_text(encoding="utf-8"))
            self.assertTrue(data["temporal_brightness_regions"]["enabled"])
            self.assertEqual(data["temporal_brightness_regions"]["report"]["region_count"], report["region_count"])


if __name__ == "__main__":
    unittest.main()
