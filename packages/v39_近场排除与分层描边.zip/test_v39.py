"""Regression checks for excluding original scan-line near-field samples."""

import unittest

import numpy as np

from confidence_contours_v39 import (
    GREEN, add_closed_contours, analyze_frame, analyze_sequence,
    near_field_exclusion_mask,
)
from ultrasound_bin_gui import ProcessParams, build_contour_params, dsc_scan_convert
from volume_pipeline_v39 import (
    SweepGeometry, full_volume_region_pipeline, reconstruct_volume,
)


class V39Tests(unittest.TestCase):
    @staticmethod
    def input_frames() -> tuple[np.ndarray, ProcessParams]:
        params = ProcessParams(
            width=100, height=64, dsc_enabled=True,
            dsc_angle_deg=60.0, dsc_inner_radius=8.0,
            dsc_output_height=160, dsc_output_width=160,
            near_field_exclusion_percent=20.0,
        )
        raw = np.full((7, 64, 100), 35, dtype=np.uint8)
        raw[:, :, :20] = 225
        raw[:, :, 45:80] = 210
        return dsc_scan_convert(raw, params), params

    def test_mask_maps_raw_left_side_to_top_curved_sector(self):
        frames, params = self.input_frames()
        excluded = near_field_exclusion_mask(frames.shape[1:], build_contour_params(params))
        centre = frames.shape[2] // 2
        self.assertTrue(excluded[30, centre])
        self.assertFalse(excluded[85, centre])
        self.assertFalse(excluded[30, 0])
        self.assertGreater(int(frames[0][excluded].max()), 200)

    def test_single_frame_and_flow_never_draw_in_excluded_sector(self):
        frames, params = self.input_frames()
        contour_params = build_contour_params(params)
        excluded = near_field_exclusion_mask(frames.shape[1:], contour_params)
        analysis = analyze_frame(frames[0], contour_params)
        small_excluded = near_field_exclusion_mask(analysis.gray.shape, contour_params)
        self.assertFalse(np.any(analysis.mask[small_excluded]))
        self.assertFalse(np.any(analysis.contour[small_excluded]))
        overlay, _ = add_closed_contours(frames[0], contour_params)
        self.assertFalse(np.any(np.all(overlay[excluded] == GREEN, axis=1)))
        masks, _ = analyze_sequence(frames, contour_params, 145.0,
                                    np.linspace(-6, 6, len(frames)))
        self.assertFalse(np.any(masks[:, small_excluded]))
        self.assertGreater(int(np.count_nonzero(masks)), 0)

    def test_volume_reconstruction_and_layers_exclude_near_field(self):
        frames, params = self.input_frames()
        original = frames.copy()
        geometry = SweepGeometry(
            tuple(float(x) for x in np.linspace(-6, 6, len(frames))),
            sample_scale_mm=0.5, scan_angle_deg=60.0,
            inner_radius_samples=8.0, sample_count=100,
            voxel_size_mm=2.0, near_field_exclusion_mm=8.0,
        )
        cutoff = (8.0 + 0.2 * 99) * 0.5
        volume, origin = reconstruct_volume(frames, geometry,
                                            exclude_below_radius_mm=cutoff)
        centre_z = int(round(-origin[0] / geometry.voxel_size_mm))
        centre_x = int(round(-origin[2] / geometry.voxel_size_mm))
        self.assertEqual(int(volume[centre_z, 4, centre_x]), 0)
        self.assertGreater(int(volume[centre_z, 16, centre_x]), 0)
        result = full_volume_region_pipeline(
            frames, geometry, radial_shadow_strength=0.0,
            contour_params=build_contour_params(params),
        )
        excluded = near_field_exclusion_mask(frames.shape[1:], build_contour_params(params))
        self.assertFalse(np.any(result.projected_labels[:, excluded]))
        self.assertGreater(int(np.count_nonzero(result.projected_labels)), 0)
        self.assertEqual(result.report["near_field_exclusion"]["raw_sample_fraction"], 0.2)
        np.testing.assert_array_equal(frames, original)


if __name__ == "__main__":
    unittest.main()
