"""Regression checks for v36 spatial volume segmentation and projection."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from volume_pipeline_v39 import (
    SweepGeometry, _rag_merge, export_volume_result,
    full_volume_region_pipeline,
)


class V36Tests(unittest.TestCase):
    @staticmethod
    def sequence() -> np.ndarray:
        frames = np.zeros((7, 80, 100), dtype=np.uint8)
        frames[:, 8:75, 8:92] = 30
        frames[:, 10:15, 10:90] = 220  # shallow horizontal artifact
        frames[:, 27:48, 34:66] = 195
        return frames

    @staticmethod
    def geometry() -> SweepGeometry:
        return SweepGeometry(
            tuple(float(x) for x in np.linspace(-15, 15, 7)),
            sample_scale_mm=0.5, scan_angle_deg=70,
            inner_radius_samples=0, sample_count=100,
            voxel_size_mm=2.0, near_field_exclusion_mm=12.0,
        )

    def test_volume_watershed_projection_excludes_shallow_horizontal_band(self):
        result = full_volume_region_pipeline(self.sequence(), self.geometry())
        self.assertEqual(result.projected_labels.shape, self.sequence().shape)
        self.assertGreater(result.report["region_count"], 0)
        self.assertGreater(int(np.count_nonzero(result.projected_labels[:, 28:47, 35:65])), 0)
        self.assertEqual(int(np.count_nonzero(result.projected_labels[:, 10:15])), 0)
        self.assertIn("watershed", result.report["algorithm"])
        self.assertIn("approximate-unverified", result.report["geometry_status"])

    def test_rag_merges_similar_basins_but_respects_strong_edge(self):
        labels = np.ones((4, 4, 6), dtype=np.int32)
        labels[:, :, 3:] = 2
        intensity = np.full(labels.shape, 100, dtype=np.uint8)
        intensity[:, :, 3:] = 103
        smooth = np.ones(labels.shape, dtype=np.float32)
        merged, report = _rag_merge(labels, intensity, smooth, 55, 90)
        self.assertEqual(report["merged_pairs"], 1)
        self.assertEqual(len(np.unique(merged)), 1)
        edge = smooth.copy()
        edge[:, :, 2:4] = 30
        separated, report = _rag_merge(labels, intensity, edge, 55, 90)
        self.assertEqual(report["merged_pairs"], 0)
        self.assertEqual(len(np.unique(separated)), 2)

    def test_exports_volume_metadata_and_marching_cubes_mesh(self):
        result = full_volume_region_pipeline(self.sequence(), self.geometry())
        with tempfile.TemporaryDirectory() as directory:
            files = export_volume_result(Path(directory), "study", result, mesh_limit=1)
            metadata = json.loads(Path(files["volume_metadata"]).read_text(encoding="utf-8"))
            self.assertEqual(metadata["storage_order"], "[z, y, x] row-major little-endian")
            self.assertEqual(metadata["volume_shape_zyx"], list(result.labels.shape))
            self.assertGreaterEqual(files["mesh_count"], 1)
            self.assertTrue(Path(metadata["mesh_files"][0]).read_bytes().startswith(b"ply\n"))


if __name__ == "__main__":
    unittest.main()
