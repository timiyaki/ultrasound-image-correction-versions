from __future__ import annotations

import json
import math
import queue
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageDraw, ImageTk


APP_TITLE = "超声 BIN 灰度帧校正工具"
COMMON_WIDTHS = (128, 192, 256, 320, 384, 480, 512, 640, 768, 800, 1024, 1280, 1920)


@dataclass
class ProcessParams:
    width: int = 512
    height: int = 96
    frame_count: int = 0
    offset_bytes: int = 0
    black_level: float = 0.0
    white_percentile: float = 99.8
    alpha: float = 1.10
    beta: float = 0.0
    gamma: float = 0.92
    lee_window: int = 5
    noise_percentile: float = 25.0
    original_blend: float = 0.15
    transpose_output: bool = False


def validate_params(path: Path, p: ProcessParams) -> int:
    if not path.is_file():
        raise ValueError("请选择有效的 .bin 文件。")
    if p.width <= 0 or p.height <= 0:
        raise ValueError("宽度和高度必须大于 0。")
    if p.offset_bytes < 0:
        raise ValueError("文件头字节数不能小于 0。")
    if p.lee_window not in (3, 5, 7, 9):
        raise ValueError("Lee 窗口必须为 3、5、7 或 9。")
    if not 90.0 <= p.white_percentile <= 100.0:
        raise ValueError("白点百分位应在 90–100 之间。")
    if not 0.1 <= p.alpha <= 5.0:
        raise ValueError("α 对比度增益应在 0.1–5.0 之间。")
    if not -255.0 <= p.beta <= 255.0:
        raise ValueError("β 亮度偏移应在 -255–255 灰度级之间。")
    if not 0.1 <= p.gamma <= 3.0:
        raise ValueError("Gamma 应在 0.1–3.0 之间。")
    if not 0.0 <= p.original_blend <= 1.0:
        raise ValueError("原始细节混合比例应在 0–1 之间。")
    samples = path.stat().st_size - p.offset_bytes
    frame_size = p.width * p.height
    if samples <= 0 or samples % frame_size:
        raise ValueError(
            f"扣除文件头后有 {samples:,} 字节，不能被单帧大小 "
            f"{p.width}×{p.height}={frame_size:,} 整除。"
        )
    inferred_count = samples // frame_size
    if p.frame_count not in (0, inferred_count):
        raise ValueError(f"帧数应为 {inferred_count}；或填 0 让程序自动计算。")
    return inferred_count


def read_frames(path: Path, p: ProcessParams) -> np.ndarray:
    count = validate_params(path, p)
    data = np.fromfile(path, dtype=np.uint8, offset=p.offset_bytes)
    return data.reshape(count, p.height, p.width)


def box_mean(x: np.ndarray, radius: int) -> np.ndarray:
    """Reflect-padded box mean for [N,H,W] float arrays."""
    k = radius * 2 + 1
    padded = np.pad(x, ((0, 0), (radius, radius), (radius, radius)), mode="reflect")
    integ = np.pad(padded, ((0, 0), (1, 0), (1, 0)), mode="constant")
    integ = np.cumsum(np.cumsum(integ, axis=1), axis=2)
    total = (
        integ[:, k:, k:]
        - integ[:, :-k, k:]
        - integ[:, k:, :-k]
        + integ[:, :-k, :-k]
    )
    return total / float(k * k)


def estimate_noise_variance(frames: np.ndarray, p: ProcessParams) -> float:
    radius = p.lee_window // 2
    sample_ids = np.linspace(0, len(frames) - 1, min(12, len(frames)), dtype=int)
    sample = frames[sample_ids].astype(np.float32)
    z = np.log1p(sample) / math.log(256.0)
    mean = box_mean(z, radius)
    var = np.maximum(box_mean(z * z, radius) - mean * mean, 0.0)
    valid = var[sample > max(8.0, p.black_level)]
    if valid.size == 0:
        return float(np.percentile(var, p.noise_percentile))
    return float(np.percentile(valid, p.noise_percentile))


def filter_chunk(frames: np.ndarray, p: ProcessParams, noise_var: float) -> np.ndarray:
    radius = p.lee_window // 2
    src = frames.astype(np.float32)
    src = np.maximum(src - p.black_level, 0.0)
    z = np.log1p(src) / math.log(256.0)
    local_mean = box_mean(z, radius)
    local_var = np.maximum(box_mean(z * z, radius) - local_mean * local_mean, 0.0)
    weight = np.clip((local_var - noise_var) / (local_var + 1e-8), 0.0, 1.0)
    lee = local_mean + weight * (z - local_mean)
    mixed = (1.0 - p.original_blend) * lee + p.original_blend * z
    corrected = np.expm1(mixed * math.log(256.0))
    corrected[src <= 0] = 0.0
    return corrected


def process_frames(
    frames: np.ndarray,
    p: ProcessParams,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, dict]:
    noise_var = estimate_noise_variance(frames, p)
    # Estimate one common white point to preserve brightness relationships between frames.
    sample_ids = np.linspace(0, len(frames) - 1, min(16, len(frames)), dtype=int)
    filtered_sample = filter_chunk(frames[sample_ids], p, noise_var)
    white = float(np.percentile(filtered_sample, p.white_percentile))
    white = max(white, 1.0)

    output = np.empty_like(frames)
    chunk_size = max(1, min(16, 24_000_000 // max(frames.shape[1] * frames.shape[2], 1)))
    for start in range(0, len(frames), chunk_size):
        end = min(start + chunk_size, len(frames))
        filtered = filter_chunk(frames[start:end], p, noise_var)
        normalized = np.clip(filtered / white, 0.0, 1.0)
        # Combined contrast/brightness/gamma correction:
        # y = 255 * clip(alpha*x + beta/255, 0, 1) ** gamma
        adjusted = np.clip(p.alpha * normalized + p.beta / 255.0, 0.0, 1.0)
        output[start:end] = np.rint(255.0 * np.power(adjusted, p.gamma)).astype(np.uint8)
        if progress:
            progress(end / len(frames), f"正在处理 {end}/{len(frames)} 帧")

    meta = {
        "algorithm": "log-domain adaptive Lee",
        "gray_correction": {
            "name": "alpha-beta-gamma correction",
            "formula": "y = 255 * clip(alpha*x + beta/255, 0, 1)^gamma",
            "alpha_contrast_gain": p.alpha,
            "beta_brightness_gray_levels": p.beta,
            "gamma": p.gamma,
        },
        "estimated_log_noise_variance": noise_var,
        "global_white_value": white,
        "parameters": asdict(p),
        "input_shape": list(frames.shape),
        "output_shape": list(output.shape),
        "raw_statistics": stats(frames),
        "processed_statistics": stats(output),
    }
    return output, meta


def stats(a: np.ndarray) -> dict:
    return {
        "minimum": int(a.min()),
        "maximum": int(a.max()),
        "mean": float(a.mean()),
        "standard_deviation": float(a.std()),
        "percentiles": {
            str(q): float(v)
            for q, v in zip((1, 5, 25, 50, 75, 95, 99), np.percentile(a, (1, 5, 25, 50, 75, 95, 99)))
        },
    }


def score_layout(data: np.ndarray, width: int, height: int) -> tuple[float, float, float]:
    count = data.size // (width * height)
    if count < 2 or data.size != count * width * height:
        return (-1e9, 0.0, 0.0)
    frames = data.reshape(count, height, width).astype(np.float32)
    ids = np.linspace(0, count - 2, min(12, count - 1), dtype=int)
    correlations = []
    for i in ids:
        a, b = frames[i].ravel(), frames[i + 1].ravel()
        sa, sb = float(a.std()), float(b.std())
        if sa > 0 and sb > 0:
            correlations.append(float(np.corrcoef(a, b)[0, 1]))
    corr = float(np.mean(correlations)) if correlations else 0.0
    within = float(np.mean(np.abs(np.diff(frames[: min(8, count)], axis=1))))
    boundary = float(np.mean(np.abs(frames[:-1, -1] - frames[1:, 0])))
    boundary_ratio = boundary / max(within, 1e-6)
    score = corr + 0.12 * min(boundary_ratio, 6.0)
    return score, corr, boundary_ratio


def infer_layout(path: Path, offset_bytes: int = 0) -> list[dict]:
    total = path.stat().st_size - offset_bytes
    if total <= 0:
        raise ValueError("文件中没有可读取的数据。")
    data = np.fromfile(path, dtype=np.uint8, offset=offset_bytes)
    candidates = []
    for width in COMMON_WIDTHS:
        if total % width:
            continue
        rows = total // width
        for height in range(32, min(1024, rows) + 1):
            if rows % height:
                continue
            count = rows // height
            if not 2 <= count <= 5000:
                continue
            score, corr, ratio = score_layout(data, width, height)
            candidates.append(
                {
                    "width": width,
                    "height": height,
                    "frame_count": count,
                    "score": score,
                    "adjacent_correlation": corr,
                    "boundary_ratio": ratio,
                }
            )
    return sorted(candidates, key=lambda x: x["score"], reverse=True)[:12]


def export_results(
    input_path: Path,
    output_dir: Path,
    raw: np.ndarray,
    processed: np.ndarray,
    meta: dict,
    p: ProcessParams,
    progress: Callable[[float, str], None] | None = None,
):
    output_dir.mkdir(parents=True, exist_ok=True)
    out_frames = processed.transpose(0, 2, 1) if p.transpose_output else processed
    bin_path = output_dir / f"{input_path.stem}_corrected_u8.bin"
    out_frames.tofile(bin_path)

    png_dir = output_dir / f"{input_path.stem}_corrected_png"
    png_dir.mkdir(exist_ok=True)
    for i, frame in enumerate(out_frames):
        Image.fromarray(frame, mode="L").save(png_dir / f"frame_{i + 1:04d}.png")
        if progress and (i % 10 == 0 or i + 1 == len(out_frames)):
            progress((i + 1) / len(out_frames), f"正在导出 PNG {i + 1}/{len(out_frames)}")

    compare_path = output_dir / f"{input_path.stem}_before_after.png"
    make_comparison(raw, processed, compare_path)
    meta.update(
        {
            "input_file": str(input_path),
            "binary_output": str(bin_path),
            "png_folder": str(png_dir),
            "comparison_image": str(compare_path),
            "binary_storage_shape": list(out_frames.shape),
        }
    )
    (output_dir / f"{input_path.stem}_processing.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return bin_path, png_dir, compare_path


def make_comparison(raw: np.ndarray, processed: np.ndarray, path: Path):
    selected = np.linspace(0, len(raw) - 1, min(6, len(raw)), dtype=int)
    display_w = min(640, max(320, raw.shape[2]))
    scale = display_w / raw.shape[2]
    display_h = max(1, round(raw.shape[1] * scale))
    margin, gap, label_h = 16, 16, 20
    canvas = Image.new(
        "RGB",
        (margin * 2 + display_w * 2 + gap, 44 + len(selected) * (display_h + label_h + 8)),
        (16, 18, 21),
    )
    d = ImageDraw.Draw(canvas)
    d.text((margin, 12), "Raw / 原图", fill=(130, 185, 255))
    d.text((margin + display_w + gap, 12), "Corrected / 校正", fill=(110, 230, 160))
    y = 42
    for idx in selected:
        d.text((margin, y), f"Frame {idx + 1}", fill=(220, 220, 220))
        y += label_h
        a = Image.fromarray(raw[idx], mode="L").resize((display_w, display_h), Image.Resampling.LANCZOS)
        b = Image.fromarray(processed[idx], mode="L").resize((display_w, display_h), Image.Resampling.LANCZOS)
        canvas.paste(a.convert("RGB"), (margin, y))
        canvas.paste(b.convert("RGB"), (margin + display_w + gap, y))
        y += display_h + 8
    canvas.save(path)


class UltrasoundApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1240x820")
        self.minsize(1040, 700)
        self.option_add("*Font", ("Microsoft YaHei UI", 10))
        self.task_queue: queue.Queue = queue.Queue()
        self.raw: np.ndarray | None = None
        self.processed: np.ndarray | None = None
        self.meta: dict | None = None
        self.preview_images = []
        self._build_ui()
        self.after(100, self._poll_queue)

    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        controls = ttk.Frame(self, padding=12)
        controls.grid(row=0, column=0, sticky="nsw")
        preview = ttk.Frame(self, padding=(4, 12, 12, 12))
        preview.grid(row=0, column=1, sticky="nsew")
        preview.columnconfigure((0, 1), weight=1)
        preview.rowconfigure(1, weight=1)

        io = ttk.LabelFrame(controls, text="文件", padding=10)
        io.pack(fill="x", pady=(0, 10))
        self.input_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self._entry_row(io, "输入 BIN", self.input_var, self._browse_input)
        self._entry_row(io, "输出目录", self.output_var, self._browse_output)
        ttk.Button(io, text="自动推断尺寸", command=self._infer).pack(fill="x", pady=(8, 0))

        layout = ttk.LabelFrame(controls, text="数据结构", padding=10)
        layout.pack(fill="x", pady=(0, 10))
        self.width_var = tk.StringVar(value="512")
        self.height_var = tk.StringVar(value="96")
        self.count_var = tk.StringVar(value="0")
        self.offset_var = tk.StringVar(value="0")
        self.transpose_var = tk.BooleanVar(value=False)
        self._grid_field(layout, 0, "宽度", self.width_var)
        self._grid_field(layout, 1, "高度", self.height_var)
        self._grid_field(layout, 2, "帧数（0=自动）", self.count_var)
        self._grid_field(layout, 3, "文件头字节", self.offset_var)
        ttk.Checkbutton(layout, text="导出时转置宽高", variable=self.transpose_var).grid(
            row=4, column=0, columnspan=2, sticky="w", pady=(5, 0)
        )

        params = ttk.LabelFrame(controls, text="校正参数", padding=10)
        params.pack(fill="x", pady=(0, 10))
        self.black_var = tk.StringVar(value="0")
        self.white_var = tk.StringVar(value="99.8")
        self.alpha_var = tk.StringVar(value="1.10")
        self.beta_var = tk.StringVar(value="0")
        self.gamma_var = tk.StringVar(value="0.92")
        self.window_var = tk.StringVar(value="5")
        self.noise_var = tk.StringVar(value="25")
        self.blend_var = tk.StringVar(value="0.15")
        self._grid_field(params, 0, "黑电平", self.black_var)
        self._grid_field(params, 1, "白点百分位", self.white_var)
        self._grid_field(params, 2, "α 对比度增益", self.alpha_var)
        self._grid_field(params, 3, "β 亮度偏移", self.beta_var)
        self._grid_field(params, 4, "γ Gamma", self.gamma_var)
        ttk.Combobox(params, textvariable=self.window_var, values=(3, 5, 7, 9), width=12, state="readonly").grid(
            row=5, column=1, sticky="ew", pady=3
        )
        ttk.Label(params, text="Lee 窗口").grid(row=5, column=0, sticky="w", pady=3)
        self._grid_field(params, 6, "噪声百分位", self.noise_var)
        self._grid_field(params, 7, "原始细节混合", self.blend_var)
        presets = ttk.Frame(params)
        presets.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        ttk.Button(presets, text="保守", command=lambda: self._set_abg(1.00, 0, 1.00)).pack(side="left", expand=True, fill="x")
        ttk.Button(presets, text="推荐", command=lambda: self._set_abg(1.10, 0, 0.92)).pack(side="left", expand=True, fill="x", padx=4)
        ttk.Button(presets, text="增强", command=lambda: self._set_abg(1.20, 5, 0.85)).pack(side="left", expand=True, fill="x")

        actions = ttk.Frame(controls)
        actions.pack(fill="x")
        self.preview_button = ttk.Button(actions, text="载入并预览", command=self._preview)
        self.preview_button.pack(side="left", expand=True, fill="x", padx=(0, 5))
        self.export_button = ttk.Button(actions, text="处理并导出", command=self._export)
        self.export_button.pack(side="left", expand=True, fill="x")
        self.progress = ttk.Progressbar(controls, mode="determinate")
        self.progress.pack(fill="x", pady=(12, 4))
        self.status_var = tk.StringVar(value="请选择 uint8 灰度帧 .bin 文件。")
        ttk.Label(controls, textvariable=self.status_var, wraplength=340).pack(fill="x")

        ttk.Label(preview, text="原始帧").grid(row=0, column=0)
        ttk.Label(preview, text="校正后").grid(row=0, column=1)
        self.raw_label = ttk.Label(preview, anchor="center")
        self.raw_label.grid(row=1, column=0, sticky="nsew", padx=(0, 4))
        self.processed_label = ttk.Label(preview, anchor="center")
        self.processed_label.grid(row=1, column=1, sticky="nsew", padx=(4, 0))
        nav = ttk.Frame(preview)
        nav.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
        nav.columnconfigure(1, weight=1)
        ttk.Label(nav, text="帧").grid(row=0, column=0)
        self.frame_var = tk.IntVar(value=1)
        self.frame_scale = ttk.Scale(nav, from_=1, to=1, variable=self.frame_var, command=lambda _v: self._show_frame())
        self.frame_scale.grid(row=0, column=1, sticky="ew", padx=8)
        self.frame_text = ttk.Label(nav, text="1 / 1")
        self.frame_text.grid(row=0, column=2)

    @staticmethod
    def _entry_row(parent, label, variable, command):
        ttk.Label(parent, text=label).pack(anchor="w")
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=(2, 6))
        ttk.Entry(row, textvariable=variable, width=34).pack(side="left", expand=True, fill="x")
        ttk.Button(row, text="浏览", command=command, width=7).pack(side="left", padx=(5, 0))

    @staticmethod
    def _grid_field(parent, row, label, variable):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(parent, textvariable=variable, width=14).grid(row=row, column=1, sticky="ew", pady=3)

    def _browse_input(self):
        name = filedialog.askopenfilename(title="选择 uint8 BIN 文件", filetypes=[("BIN 文件", "*.bin"), ("所有文件", "*.*")])
        if name:
            self.input_var.set(name)
            if not self.output_var.get():
                self.output_var.set(str(Path(name).parent / "corrected_output"))

    def _browse_output(self):
        name = filedialog.askdirectory(title="选择输出目录")
        if name:
            self.output_var.set(name)

    def _params(self) -> ProcessParams:
        try:
            return ProcessParams(
                width=int(self.width_var.get()), height=int(self.height_var.get()), frame_count=int(self.count_var.get()),
                offset_bytes=int(self.offset_var.get()), black_level=float(self.black_var.get()),
                white_percentile=float(self.white_var.get()), alpha=float(self.alpha_var.get()),
                beta=float(self.beta_var.get()), gamma=float(self.gamma_var.get()),
                lee_window=int(self.window_var.get()), noise_percentile=float(self.noise_var.get()),
                original_blend=float(self.blend_var.get()), transpose_output=bool(self.transpose_var.get()),
            )
        except ValueError as exc:
            raise ValueError("参数中含有无效数字。") from exc

    def _set_abg(self, alpha: float, beta: float, gamma: float):
        self.alpha_var.set(f"{alpha:.2f}")
        self.beta_var.set(f"{beta:g}")
        self.gamma_var.set(f"{gamma:.2f}")
        self.status_var.set(f"已设置 α={alpha:.2f}、β={beta:g}、γ={gamma:.2f}；点击“载入并预览”查看效果。")

    def _set_busy(self, busy: bool):
        state = "disabled" if busy else "normal"
        self.preview_button.configure(state=state)
        self.export_button.configure(state=state)
        if not busy:
            self.progress["value"] = 0

    def _run_task(self, func):
        self._set_busy(True)
        threading.Thread(target=func, daemon=True).start()

    def _infer(self):
        def task():
            try:
                path = Path(self.input_var.get())
                offset = int(self.offset_var.get())
                choices = infer_layout(path, offset)
                if not choices:
                    raise ValueError("没有找到可用候选，请手动填写宽度和高度。")
                self.task_queue.put(("inferred", choices))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))
        self.status_var.set("正在分析候选尺寸…")
        self._run_task(task)

    def _preview(self):
        def task():
            try:
                path, p = Path(self.input_var.get()), self._params()
                raw = read_frames(path, p)
                corrected, meta = process_frames(raw, p, lambda x, s: self.task_queue.put(("progress", x, s)))
                self.task_queue.put(("preview", raw, corrected, meta))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))
        self.status_var.set("正在载入并处理预览…")
        self._run_task(task)

    def _export(self):
        def task():
            try:
                path, p = Path(self.input_var.get()), self._params()
                out = Path(self.output_var.get())
                raw = read_frames(path, p)
                corrected, meta = process_frames(raw, p, lambda x, s: self.task_queue.put(("progress", x * .65, s)))
                files = export_results(path, out, raw, corrected, meta, p, lambda x, s: self.task_queue.put(("progress", .65 + x * .35, s)))
                self.task_queue.put(("exported", raw, corrected, meta, files))
            except Exception as exc:
                self.task_queue.put(("error", str(exc)))
        self.status_var.set("正在处理全部帧…")
        self._run_task(task)

    def _poll_queue(self):
        try:
            while True:
                item = self.task_queue.get_nowait()
                kind = item[0]
                if kind == "progress":
                    self.progress["value"] = item[1] * 100
                    self.status_var.set(item[2])
                elif kind == "error":
                    self._set_busy(False)
                    self.status_var.set("处理失败。")
                    messagebox.showerror(APP_TITLE, item[1])
                elif kind == "inferred":
                    self._set_busy(False)
                    choices = item[1]
                    best = choices[0]
                    self.width_var.set(str(best["width"]))
                    self.height_var.set(str(best["height"]))
                    self.count_var.set(str(best["frame_count"]))
                    lines = [
                        f'{i+1}. {c["frame_count"]}帧 × {c["height"]}行 × {c["width"]}列；相关={c["adjacent_correlation"]:.3f}'
                        for i, c in enumerate(choices[:5])
                    ]
                    self.status_var.set(f'已采用首选：{best["frame_count"]}×{best["height"]}×{best["width"]}')
                    messagebox.showinfo("尺寸推断结果", "首选候选已填入：\n\n" + "\n".join(lines) + "\n\n请结合图像预览确认。")
                elif kind in ("preview", "exported"):
                    self._set_busy(False)
                    self.raw, self.processed, self.meta = item[1], item[2], item[3]
                    self.frame_scale.configure(to=len(self.raw))
                    self.frame_var.set(1)
                    self._show_frame()
                    if kind == "exported":
                        files = item[4]
                        self.status_var.set(f"导出完成：{files[0].parent}")
                        messagebox.showinfo(APP_TITLE, f"处理完成。\n\nBIN：{files[0]}\nPNG：{files[1]}\n对比图：{files[2]}")
                    else:
                        self.status_var.set(f"预览完成，共 {len(self.raw)} 帧。")
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)

    def _show_frame(self):
        if self.raw is None or self.processed is None:
            return
        i = max(0, min(len(self.raw) - 1, round(float(self.frame_var.get())) - 1))
        self.frame_text.configure(text=f"{i + 1} / {len(self.raw)}")
        self.preview_images = [self._photo(self.raw[i]), self._photo(self.processed[i])]
        self.raw_label.configure(image=self.preview_images[0])
        self.processed_label.configure(image=self.preview_images[1])

    @staticmethod
    def _photo(frame: np.ndarray) -> ImageTk.PhotoImage:
        image = Image.fromarray(frame, mode="L")
        max_w, max_h = 430, 610
        scale = min(max_w / image.width, max_h / image.height, 4.0)
        image = image.resize((max(1, round(image.width * scale)), max(1, round(image.height * scale))), Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(image)


if __name__ == "__main__":
    UltrasoundApp().mainloop()
