@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "BUNDLED_PYTHON=C:\Users\timiy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if exist "%BUNDLED_PYTHON%" (
  "%BUNDLED_PYTHON%" ultrasound_bin_gui.py
) else (
  python ultrasound_bin_gui.py
)

if errorlevel 1 (
  echo.
  echo 启动失败。请在 VS Code 中打开 UltrasoundBinCorrection.code-workspace，
  echo 或运行：python -m pip install -r requirements.txt
  pause
)
