import unittest
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

from adaptive_edge_v30 import (
    analyze_edge_frame, apply_adaptive_edge_response,
    prepare_adaptive_edge_response,
)
from ultrasound_bin_gui import (
    PreviewRenderer, ProcessParams, add_diffused_dual_outline,
    estimate_outline_thresholds, export_results, process_frames,
)


class V30Tests(unittest.TestCase):
    def test_red_only_marks_internal_dark_non_dark_boundary(self):
        frame = np.zeros((96, 96), np.uint8)
        frame[8:88, 8:88] = 85
        frame[35:61, 35:61] = 0
        frame[65:78, 65:78] = 210
        result = add_diffused_dual_outline(frame, 24, 165, 3)
        red = np.all(result == (255, 32, 32), axis=2)
        blue = np.all(result == (32, 112, 255), axis=2)
        self.assertGreater(np.count_nonzero(red[32:64, 32:64]), 20)
        self.assertEqual(np.count_nonzero(red[6:12, :]), 0)
        self.assertEqual(np.count_nonzero(red[:, 6:12]), 0)
        self.assertGreater(np.count_nonzero(blue[63:81, 63:81]), 0)

    def test_bright_auto_threshold_covers_bright_patch(self):
        frame = np.full((96, 96), 25, np.uint8)
        frame[14:82, 14:82] = 100
        frame[30:55, 38:65] = 190
        red, blue = estimate_outline_thresholds(frame)
        self.assertLess(red, 100)
        self.assertGreater(blue, red + 40)
        self.assertLess(blue, 190)

    def test_auto_edge_factor_reacts_to_texture_and_preserves_black(self):
        rng = np.random.default_rng(42)
        clean = np.zeros((96, 96), np.uint8)
        clean[12:84, 12:84] = 80
        clean[34:62, 34:62] = 170
        noisy = clean.copy()
        tile = noisy[12:84, 12:84].astype(np.int16)
        noisy[12:84, 12:84] = np.clip(tile + rng.integers(-24, 25, tile.shape), 1, 245)
        self.assertGreater(analyze_edge_frame(clean)["auto_factor"],
                           analyze_edge_frame(noisy)["auto_factor"])
        response = prepare_adaptive_edge_response(clean)
        result, report = apply_adaptive_edge_response(clean, response, 1.0, True)
        self.assertEqual(int(result[0, 0]), 0)
        self.assertGreater(report["effective_gain"], 0)

    def test_exact_preview_agrees_with_export_pipeline(self):
        raw = np.zeros((2, 48, 64), np.uint8)
        raw[:, 4:44, 4:60] = 65
        raw[:, 17:32, 20:47] = 150
        p = ProcessParams(width=64, height=48, edge_auto_enabled=True)
        expected, _ = process_frames(raw, p)
        _, _, preview, _ = PreviewRenderer().render(raw, 0, p, exact_edges=True)
        np.testing.assert_array_equal(preview, expected[0])

    def test_export_keeps_gray_bin_and_three_comparison_columns(self):
        raw = np.zeros((2, 48, 64), np.uint8)
        raw[:, 4:44, 4:60] = 65
        raw[:, 17:32, 20:47] = 150
        p = ProcessParams(width=64, height=48)
        processed, meta = process_frames(raw, p)
        with tempfile.TemporaryDirectory() as directory:
            bin_path, png_dir, comparison = export_results(
                Path("raw_frames_u8.bin"), Path(directory), raw, processed, meta, p,
            )
            np.testing.assert_array_equal(np.fromfile(bin_path, np.uint8), processed.ravel())
            self.assertTrue((png_dir / "frame_0001.png").is_file())
            with Image.open(comparison) as image:
                self.assertEqual(image.width, 1024)


if __name__ == "__main__":
    unittest.main()
