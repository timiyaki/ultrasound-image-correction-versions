"""Regression checks for the v38 confidence/contour/flow sequence."""

import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

from confidence_contours_v38 import (
    GREEN, ContourParams, add_closed_contours, analyze_frame,
    analyze_sequence,
)
from ultrasound_bin_gui import ProcessParams, build_contour_params, export_results
from volume_pipeline_v38 import SweepGeometry, full_volume_region_pipeline


class V38Tests(unittest.TestCase):
    @staticmethod
    def frame() -> np.ndarray:
        frame = np.zeros((90, 130), dtype=np.uint8)
        frame[7:84, 8:122] = 35
        frame[25:65, 25:58] = 156
        frame[25:65, 58:102] = 222
        return frame

    def test_confidence_rejects_some_canny_edges_and_contours_are_closed(self):
        result = analyze_frame(
            self.frame(), ContourParams(working_width=130, confidence_threshold=0.9),
        )
        self.assertGreater(result.report["candidate_pixels"], 0)
        self.assertLess(result.report["reliable_pixels"], result.report["candidate_pixels"])
        self.assertGreater(result.report["closed_pixels"], 0)
        self.assertGreater(result.report["active_area"], 0)
        self.assertTrue(np.array_equal(
            result.contour, result.mask & ~ndi.binary_erosion(result.mask),
        ))
        self.assertEqual(int(result.contour[0].sum()), 0)

    def test_manual_confidence_threshold_changes_reliable_edges(self):
        low = analyze_frame(self.frame(), ContourParams(working_width=130,
                                                        confidence_threshold=0.2))
        high = analyze_frame(self.frame(), ContourParams(working_width=130,
                                                         confidence_threshold=0.9))
        self.assertGreater(low.report["reliable_pixels"], high.report["reliable_pixels"])
        colored, threshold = add_closed_contours(
            self.frame(), ContourParams(working_width=130,
                                        confidence_threshold=0.2),
        )
        self.assertEqual(threshold, 0.2)
        self.assertGreater(int(np.all(colored == GREEN, axis=2).sum()), 0)

    def test_optical_flow_links_adjacent_frames_and_volume_uses_contours(self):
        base = self.frame()
        frames = np.stack([np.roll(base, shift=i, axis=1) for i in range(7)])
        angles = np.linspace(-9, 9, len(frames))
        masks, report = analyze_sequence(
            frames, ContourParams(working_width=130), 135.0, angles,
        )
        self.assertEqual(masks.shape[0], len(frames))
        self.assertEqual(report["flow_pairs"], len(frames) - 1)
        self.assertGreater(int(np.count_nonzero(masks)), 0)
        geometry = SweepGeometry(tuple(angles), 0.5, 70.0, 0, 130,
                                 voxel_size_mm=2.0, near_field_exclusion_mm=9.0)
        result = full_volume_region_pipeline(
            frames, geometry, bright_reference=130, min_brightness_gap=25,
        )
        self.assertTrue(result.report["contour_guidance_applied"])
        self.assertEqual(result.report["edge_contour_pipeline"]["flow_pairs"], 6)
        self.assertEqual(result.projected_labels.shape, frames.shape)

    def test_export_keeps_grayscale_binary_and_new_contour_metadata(self):
        frames = np.stack([self.frame(), self.frame()])
        params = ProcessParams(width=130, height=90, gradient_outline_auto=False,
                               gradient_outline_threshold=35)
        self.assertEqual(build_contour_params(params).confidence_threshold, 0.35)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            gray_bin, png_dir, _ = export_results(
                Path('raw_frames_u8.bin'), root, frames, frames, {}, params,
            )
            np.testing.assert_array_equal(
                np.fromfile(gray_bin, dtype=np.uint8).reshape(frames.shape), frames,
            )
            with Image.open(png_dir / 'frame_0001.png') as image:
                self.assertGreater(int(np.all(np.asarray(image) == GREEN, axis=2).sum()), 0)


if __name__ == '__main__':
    unittest.main()
