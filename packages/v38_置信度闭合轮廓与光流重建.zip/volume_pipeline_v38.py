"""Geometry-aware 3-D segmentation of a mechanically swept ultrasound series.

The available FetalVision archives contain angles and pixel scale, but no
verified motor pivot/axis calibration.  The x-axis pivot model below is
explicitly approximate and must never be presented as calibrated anatomy.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from scipy import ndimage as ndi
from skimage import filters, measure, morphology, segmentation

from confidence_contours_v38 import ContourParams, analyze_sequence
from volume_regions_v35 import add_region_overlay, region_color


@dataclass(frozen=True)
class SweepGeometry:
    frame_angles_deg: tuple[float, ...]
    sample_scale_mm: float
    scan_angle_deg: float
    inner_radius_samples: float
    sample_count: int
    voxel_size_mm: float = 1.5
    pivot_depth_mm: float = 0.0
    near_field_exclusion_mm: float = 12.0

    def validate(self, frame_count: int) -> None:
        angles = np.asarray(self.frame_angles_deg, dtype=float)
        if len(angles) != frame_count or not np.all(np.isfinite(angles)):
            raise ValueError("完整三维重建需要每一帧的有效 angle3D 角度。")
        if not np.all(np.diff(angles) > 0) and not np.all(np.diff(angles) < 0):
            raise ValueError("angle3D 必须按扫描次序单调变化，不能出现重复或反转。")
        if not 0.05 <= self.sample_scale_mm <= 1.0:
            raise ValueError("sampleScale 不在可解释的毫米/采样点范围内。")
        if not 1.0 <= self.scan_angle_deg < 180.0:
            raise ValueError("扫描扇角无效。")
        if not 0.8 <= self.voxel_size_mm <= 3.0:
            raise ValueError("体素边长应在 0.8–3.0 mm。")
        if not -20.0 <= self.pivot_depth_mm <= 50.0:
            raise ValueError("摆扫轴心深度应在 -20–50 mm。")
        if not 0.0 <= self.near_field_exclusion_mm <= 40.0:
            raise ValueError("近场排除深度应在 0–40 mm。")

    @property
    def outer_radius_mm(self) -> float:
        return (self.inner_radius_samples + self.sample_count - 1) * self.sample_scale_mm

    @property
    def lateral_limit_mm(self) -> float:
        return self.outer_radius_mm * math.sin(math.radians(self.scan_angle_deg / 2))

    @property
    def centred_angles_deg(self) -> np.ndarray:
        angles = np.asarray(self.frame_angles_deg, dtype=np.float32)
        return angles - 0.5 * (float(angles.min()) + float(angles.max()))


@dataclass
class VolumeResult:
    intensity: np.ndarray
    labels: np.ndarray
    projected_labels: np.ndarray
    origin_zyx_mm: tuple[float, float, float]
    spacing_mm: float
    report: dict


def suppress_radial_shadows(
    dsc_frames: np.ndarray, geometry: SweepGeometry,
    strength: float = 0.75,
) -> tuple[np.ndarray, dict]:
    """Repair narrow, persistent dark scan-line shadows in a feature copy.

    A lateral median is taken in polar scan-line coordinates, not along image
    rows. Only dark deficits that persist radially are repaired; wide fluid
    gaps and the original display/output frames remain untouched.
    """
    if not 0.0 <= strength <= 1.0:
        raise ValueError("径向暗线抑制强度应在 0–1 之间。")
    if strength == 0:
        return dsc_frames, {"strength": 0.0, "repaired_pixels": 0}
    frame_count, height, width = dsc_frames.shape
    outer = geometry.outer_radius_mm
    lateral = geometry.lateral_limit_mm
    line_count = int(np.clip(round(geometry.scan_angle_deg * 2), 96, 192))
    radius = np.linspace(0, outer, height, dtype=np.float32)[:, None]
    theta = np.deg2rad(np.linspace(
        -geometry.scan_angle_deg / 2, geometry.scan_angle_deg / 2,
        line_count, dtype=np.float32,
    ))[None, :]
    polar_rows = np.broadcast_to(radius * np.cos(theta) * (height - 1) / outer,
                                 (height, line_count))
    polar_cols = np.broadcast_to((radius * np.sin(theta) + lateral)
                                 * (width - 1) / (2 * lateral),
                                 (height, line_count))
    yy = np.linspace(0, outer, height, dtype=np.float32)[:, None]
    xx = np.linspace(-lateral, lateral, width, dtype=np.float32)[None, :]
    image_radius = np.hypot(xx, yy)
    image_theta = np.rad2deg(np.arctan2(xx, np.maximum(yy, 1e-3)))
    inverse_rows = image_radius * (height - 1) / outer
    inverse_cols = (image_theta + geometry.scan_angle_deg / 2) * (line_count - 1) / geometry.scan_angle_deg
    inside = ((image_radius <= outer) &
              (image_radius >= geometry.inner_radius_samples * geometry.sample_scale_mm) &
              (np.abs(image_theta) <= geometry.scan_angle_deg / 2))
    output = dsc_frames.copy()
    repaired_pixels = 0
    for index in range(frame_count):
        polar = ndi.map_coordinates(
            dsc_frames[index].astype(np.float32), [polar_rows, polar_cols],
            order=1, mode="constant", cval=0.0, prefilter=False,
        )
        lateral_median = ndi.median_filter(polar, size=(1, 13))
        deficit = lateral_median - polar
        dark_streak = (deficit >= 20.0) & (lateral_median >= 105.0)
        persistence = ndi.uniform_filter1d(
            dark_streak.astype(np.float32), size=23, axis=0, mode="constant",
        ) >= 0.48
        repair = np.where(dark_streak & persistence, deficit * strength, 0.0)
        delta = ndi.map_coordinates(
            repair, [inverse_rows, inverse_cols], order=1,
            mode="constant", cval=0.0, prefilter=False,
        )
        eligible = inside & (delta >= 4.0)
        output[index][eligible] = np.clip(
            dsc_frames[index][eligible].astype(np.float32) + delta[eligible],
            0, 255,
        ).astype(np.uint8)
        repaired_pixels += int(np.count_nonzero(eligible))
    return output, {"strength": strength, "repaired_pixels": repaired_pixels,
                    "line_count": line_count, "persistence_samples": 23}


def reconstruct_volume(
    dsc_frames: np.ndarray, geometry: SweepGeometry,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, tuple[float, float, float]]:
    """Inverse-map DSC frames into a Cartesian volume with trilinear sampling.

    Assumption: the imaging plane sweeps about its in-plane lateral x-axis at
    the configured pivot depth.  This mapping is revisable if true probe
    calibration becomes available.
    """
    if dsc_frames.ndim != 3 or dsc_frames.dtype != np.uint8:
        raise ValueError("三维重建需要 [帧, 高, 宽] uint8 DSC 图像。")
    frame_count, height, width = dsc_frames.shape
    geometry.validate(frame_count)
    angles = geometry.centred_angles_deg
    frame_indices = np.arange(frame_count, dtype=np.float32)
    if angles[0] > angles[-1]:
        angles = angles[::-1]
        frame_indices = frame_indices[::-1]
    half_sweep = math.radians(float(np.max(np.abs(angles))))
    outer = geometry.outer_radius_mm
    lateral = geometry.lateral_limit_mm
    pivot = geometry.pivot_depth_mm
    z_limit = max(abs(pivot), abs(outer - pivot)) * math.sin(half_sweep)
    spacing = geometry.voxel_size_mm
    x_values = np.arange(-lateral, lateral + spacing * 0.5, spacing, dtype=np.float32)
    y_values = np.arange(0.0, outer + spacing * 0.5, spacing, dtype=np.float32)
    z_values = np.arange(-z_limit, z_limit + spacing * 0.5, spacing, dtype=np.float32)
    shape = (len(z_values), len(y_values), len(x_values))
    if np.prod(shape, dtype=np.int64) > 18_000_000:
        raise ValueError("目标体素过多，请增大体素边长以控制内存。")
    volume = np.zeros(shape, dtype=np.uint8)
    source = dsc_frames.astype(np.float32, copy=False)
    x = x_values[None, None, :]
    y = y_values[None, :, None]
    for start in range(0, len(z_values), 6):
        stop = min(start + 6, len(z_values))
        z = z_values[start:stop, None, None]
        local_axial = pivot + np.hypot(y - pivot, z)
        sweep_deg = np.rad2deg(np.arctan2(z, y - pivot))
        radius = np.hypot(x, local_axial)
        azimuth = np.rad2deg(np.arctan2(x, np.maximum(local_axial, 1e-6)))
        valid = (
            (sweep_deg >= angles[0]) & (sweep_deg <= angles[-1])
            & (radius >= geometry.inner_radius_samples * geometry.sample_scale_mm)
            & (radius <= outer)
            & (np.abs(azimuth) <= geometry.scan_angle_deg / 2)
        )
        broadcast_shape = np.broadcast_shapes(
            sweep_deg.shape, local_axial.shape, x.shape,
        )
        sweep_grid = np.broadcast_to(sweep_deg, broadcast_shape)
        axial_grid = np.broadcast_to(local_axial, broadcast_shape)
        x_grid = np.broadcast_to(x, broadcast_shape)
        frame_coord = np.interp(sweep_grid.ravel(), angles, frame_indices)
        row_coord = axial_grid.ravel() * (height - 1) / outer
        column_coord = (x_grid.ravel() + lateral) * (width - 1) / (2 * lateral)
        sampled = ndi.map_coordinates(
            source, [frame_coord, row_coord, column_coord],
            order=1, mode="constant", cval=0.0, prefilter=False,
        ).reshape(broadcast_shape)
        sampled[~np.broadcast_to(valid, broadcast_shape)] = 0
        volume[start:stop] = np.rint(sampled).astype(np.uint8)
        if progress:
            progress(stop / len(z_values), f"正在重建体数据 {stop}/{len(z_values)} 层")
    return volume, (float(z_values[0]), float(y_values[0]), float(x_values[0]))


def normalize_depth_intensity(volume: np.ndarray) -> np.ndarray:
    """Bounded depth gain equalization, leaving zero background unchanged."""
    valid = volume > 0
    profile = np.full(volume.shape[1], np.nan, dtype=np.float32)
    for y in range(volume.shape[1]):
        values = volume[:, y, :][valid[:, y, :]]
        if values.size >= 100:
            profile[y] = float(np.percentile(values, 75))
    known = np.flatnonzero(np.isfinite(profile))
    if known.size < 4:
        return volume.copy()
    profile = np.interp(np.arange(len(profile)), known, profile[known])
    profile = ndi.gaussian_filter1d(profile.astype(np.float32), 4.0)
    reference = float(np.median(profile))
    gains = np.clip(reference / np.maximum(profile, 1.0), 0.82, 1.22)
    normalized = np.clip(volume.astype(np.float32) * gains[None, :, None], 0, 255)
    normalized[~valid] = 0
    return np.rint(normalized).astype(np.uint8)


def _seed_markers(smoothed: np.ndarray, candidate: np.ndarray,
                  threshold: float, gradient: np.ndarray) -> np.ndarray:
    values = smoothed[candidate]
    if not values.size:
        return np.zeros(smoothed.shape, dtype=np.int32)
    seed_level = max(threshold + 9.0, float(np.percentile(values, 68)))
    gradient_cap = float(np.percentile(gradient[candidate], 75))
    cores = candidate & (smoothed >= seed_level) & (gradient <= gradient_cap)
    cores = morphology.remove_small_objects(cores, min_size=12, connectivity=3)
    markers, marker_count = ndi.label(cores, structure=np.ones((3, 3, 3), bool))
    # Give every disconnected candidate component at least one seed so
    # watershed does not silently discard less brilliant but valid tissue.
    components, count = ndi.label(candidate, structure=np.ones((3, 3, 3), bool))
    covered = np.unique(components[markers > 0])
    missing = np.setdiff1d(np.arange(1, count + 1), covered, assume_unique=True)
    if missing.size:
        objects = ndi.find_objects(components)
        for component_id in missing:
            box = objects[int(component_id) - 1]
            if box is None:
                continue
            area = components[box] == component_id
            intensity = np.where(area, smoothed[box], -1.0)
            local = np.unravel_index(int(np.argmax(intensity)), intensity.shape)
            location = tuple(section.start + offset for section, offset in zip(box, local))
            marker_count += 1
            markers[location] = marker_count
    return markers.astype(np.int32, copy=False)


def _rag_merge(
    regions: np.ndarray, intensity: np.ndarray, gradient: np.ndarray,
    brightness_tolerance: float, gradient_limit: float,
    tier_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, dict]:
    """Merge adjacent watershed basins only across weak, similar boundaries."""
    region_count = int(regions.max())
    if region_count == 0:
        return regions, {"initial_regions": 0, "merged_pairs": 0}
    counts = np.bincount(regions.ravel(), minlength=region_count + 1)
    sums = np.bincount(
        regions.ravel(), weights=intensity.ravel(), minlength=region_count + 1,
    )
    means = np.divide(sums, counts, out=np.zeros_like(sums), where=counts > 0)
    tiers = None
    if tier_mask is not None:
        high_counts = np.bincount(
            regions.ravel(), weights=tier_mask.ravel(), minlength=region_count + 1,
        )
        tiers = high_counts > counts * 0.5
    keys = []
    boundary_values = []
    radix = region_count + 1
    for axis in (0, 1, 2):
        first_slice = [slice(None)] * 3
        second_slice = [slice(None)] * 3
        first_slice[axis] = slice(None, -1)
        second_slice[axis] = slice(1, None)
        a = regions[tuple(first_slice)]
        b = regions[tuple(second_slice)]
        contact = (a > 0) & (b > 0) & (a != b)
        if not np.any(contact):
            continue
        low = np.minimum(a[contact], b[contact]).astype(np.int64)
        high = np.maximum(a[contact], b[contact]).astype(np.int64)
        keys.append(low * radix + high)
        boundary_values.append(np.maximum(
            gradient[tuple(first_slice)][contact],
            gradient[tuple(second_slice)][contact],
        ))
    if not keys:
        return regions, {"initial_regions": region_count, "merged_pairs": 0}
    all_keys = np.concatenate(keys)
    all_boundary = np.concatenate(boundary_values)
    edge_keys, inverse = np.unique(all_keys, return_inverse=True)
    edge_count = np.bincount(inverse)
    edge_sum = np.bincount(inverse, weights=all_boundary)
    edge_mean = edge_sum / edge_count
    low = (edge_keys // radix).astype(np.int32)
    high = (edge_keys % radix).astype(np.int32)
    gradient_reference = float(np.percentile(gradient[regions > 0], 65))
    boundary_limit = max(3.0, gradient_reference * gradient_limit / 90.0)
    intensity_cost = np.abs(means[low] - means[high]) / max(brightness_tolerance, 1.0)
    boundary_cost = edge_mean / boundary_limit
    cost = 0.62 * intensity_cost + 0.38 * boundary_cost
    order = np.argsort(cost)
    parent = np.arange(radix, dtype=np.int32)
    merged_count = 0

    def find(node: int) -> int:
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = int(parent[node])
        return node

    for edge in order:
        if cost[edge] >= 0.82:
            break
        if edge_mean[edge] >= boundary_limit:
            continue
        a, b = find(int(low[edge])), find(int(high[edge]))
        if a == b or abs(means[a] - means[b]) > brightness_tolerance:
            continue
        if tiers is not None and tiers[a] != tiers[b]:
            continue
        if counts[a] < counts[b]:
            a, b = b, a
        parent[b] = a
        sums[a] += sums[b]
        counts[a] += counts[b]
        means[a] = sums[a] / counts[a]
        merged_count += 1
    lookup = np.fromiter((find(i) for i in range(radix)), dtype=np.int32, count=radix)
    return lookup[regions], {
        "initial_regions": region_count,
        "adjacent_pairs": int(edge_keys.size),
        "merged_pairs": merged_count,
        "boundary_gradient_limit": round(boundary_limit, 3),
    }


def segment_volume(
    volume: np.ndarray, origin_zyx_mm: tuple[float, float, float],
    geometry: SweepGeometry, *, bright_reference: float = 145.0,
    brightness_tolerance: float = 30.0, gradient_limit: float = 90.0,
    min_brightness_gap: float = 28.0,
    contour_volume: np.ndarray | None = None,
    max_regions: int = 256, min_voxels: int = 24,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Reconstruct closed 2-D contours into the volume before 3-D labeling."""
    if volume.ndim != 3 or volume.dtype != np.uint8:
        raise ValueError("三维分割需要 uint8 三维体数据。")
    valid = volume > 0
    if np.count_nonzero(valid) < 1000:
        raise ValueError("有效三维体素不足，无法执行区域标注。")
    normalized = normalize_depth_intensity(volume)
    smoothed = ndi.gaussian_filter(normalized.astype(np.float32), sigma=1.0)
    otsu = filters.threshold_multiotsu(normalized[valid], classes=3)
    threshold = float(np.clip(0.7 * bright_reference + 0.3 * otsu[1], 100, 240))
    candidate = valid & (smoothed >= threshold - 12)
    depth_mm = origin_zyx_mm[1] + np.arange(volume.shape[1]) * geometry.voxel_size_mm
    candidate[:, depth_mm < geometry.near_field_exclusion_mm, :] = False
    structure = morphology.ball(1)
    closed = ndi.binary_closing(candidate, structure=structure, border_value=0)
    candidate |= closed & valid & (smoothed >= threshold - 20)
    contour_guidance_applied = False
    if contour_volume is not None:
        if contour_volume.shape != volume.shape or contour_volume.dtype != np.uint8:
            raise ValueError("闭合轮廓体必须与亮度体尺寸相同，且为 uint8。")
        guided = candidate & ndi.binary_dilation(contour_volume >= 96, iterations=1)
        if np.count_nonzero(guided) >= max(200, 0.20 * np.count_nonzero(candidate)):
            candidate = guided
            contour_guidance_applied = True
    candidate_values = normalized[candidate]
    split_threshold = (float(filters.threshold_multiotsu(candidate_values, classes=2)[0])
                       if np.unique(candidate_values).size >= 2 else 255.0)
    below = candidate_values[candidate_values < split_threshold]
    above = candidate_values[candidate_values >= split_threshold]
    class_gap = (float(above.mean() - below.mean()) if below.size and above.size else 0.0)
    split_enabled = (class_gap >= min_brightness_gap and
                     min(below.size, above.size) >= 0.04 * candidate_values.size)
    if progress:
        progress(0.20, "已完成深度归一化和多级亮度分层")
    gradient = ndi.gaussian_gradient_magnitude(smoothed, sigma=0.8)
    if contour_guidance_applied:
        prior_gradient = ndi.gaussian_gradient_magnitude(
            contour_volume.astype(np.float32) / 255.0, sigma=0.8,
        )
        gradient = np.maximum(gradient, 45.0 * prior_gradient)
    high_tier = candidate & (smoothed >= split_threshold) if split_enabled else None
    tier_masks = ([candidate & ~high_tier, high_tier] if split_enabled else [candidate])
    basins = np.zeros(volume.shape, dtype=np.int32)
    marker_count = 0
    basin_offset = 0
    for tier_index, tier_candidate in enumerate(tier_masks):
        if not np.any(tier_candidate):
            continue
        seed_floor = split_threshold if tier_index else threshold
        markers = _seed_markers(smoothed, tier_candidate, seed_floor, gradient)
        marker_count += int(markers.max())
        if not np.any(markers):
            continue
        if progress:
            progress(0.38 + tier_index * 0.08, "正在按亮度层进行三维分水岭")
        tier_basins = segmentation.watershed(
            gradient, markers, mask=tier_candidate,
            connectivity=np.ones((3, 3, 3), bool),
        )
        basins[tier_basins > 0] = tier_basins[tier_basins > 0] + basin_offset
        basin_offset = int(basins.max())
    if not np.any(basins):
        raise ValueError("没有找到可靠的三维亮区内部标记；请降低高亮基准。")
    connected = measure.label(basins, connectivity=3, background=0).astype(np.int32)
    if progress:
        progress(0.60, "正在构建三维区域邻接图并合并相似区域")
    merged, rag_report = _rag_merge(
        connected, normalized, gradient, brightness_tolerance, gradient_limit,
        tier_mask=high_tier,
    )
    counts = np.bincount(merged.ravel())
    # A broad, shallow, low-thickness slab is the characteristic residual
    # skin/probe reverberation that v35 mislabeled as a horizontal tissue line.
    # Reject the *3-D component*, not merely individual horizontal image rows.
    suppressed_sheets = []
    for region_id, box in enumerate(ndi.find_objects(merged), start=1):
        if box is None or region_id >= len(counts) or counts[region_id] < min_voxels:
            continue
        depth_min = origin_zyx_mm[1] + box[1].start * geometry.voxel_size_mm
        depth_span = (box[1].stop - box[1].start) * geometry.voxel_size_mm
        lateral_span = (box[2].stop - box[2].start) * geometry.voxel_size_mm
        sweep_span = (box[0].stop - box[0].start) * geometry.voxel_size_mm
        if (depth_min < 38.0 and depth_span < 24.0
                and lateral_span > 25.0 and sweep_span > 20.0):
            counts[region_id] = 0
            suppressed_sheets.append(region_id)
    candidates = np.flatnonzero(counts >= min_voxels)
    candidates = candidates[candidates > 0]
    selected = candidates[np.argsort(counts[candidates])[::-1][:max_regions]]
    lookup = np.zeros(len(counts), dtype=np.uint16)
    lookup[selected] = np.arange(1, len(selected) + 1, dtype=np.uint16)
    labels = lookup[merged]
    report = {
        "algorithm": "Scharr/Canny confidence and Chan-Vese closed contours, optical flow, 3-D inverse DSC reconstruction, depth normalization, Multi-Otsu intensity tiers, contour-guided 3-D watershed, 26-connected components, tier-aware RAG, Marching Cubes export",
        "geometry_status": "approximate-unverified x-axis mechanical sweep",
        "volume_shape_zyx": list(volume.shape),
        "origin_zyx_mm": list(origin_zyx_mm),
        "spacing_mm": geometry.voxel_size_mm,
        "multi_otsu_gray_thresholds": [float(x) for x in otsu],
        "effective_bright_threshold": round(threshold, 2),
        "brightness_tier_threshold": round(split_threshold, 2),
        "brightness_tier_gap": round(class_gap, 2),
        "brightness_tier_split_enabled": bool(split_enabled),
        "minimum_brightness_gap": min_brightness_gap,
        "contour_guidance_applied": contour_guidance_applied,
        "initial_marker_count": marker_count,
        "rag": rag_report,
        "region_count": len(selected),
        "near_field_exclusion_mm": geometry.near_field_exclusion_mm,
        "suppressed_shallow_sheet_regions": len(suppressed_sheets),
        "regions": [],
    }
    if progress:
        progress(0.85, "正在汇总三维区域属性")
    objects = ndi.find_objects(labels)
    sums = np.bincount(labels.ravel(), weights=normalized.ravel(), minlength=len(selected) + 1)
    kept_counts = np.bincount(labels.ravel(), minlength=len(selected) + 1)
    for region_id, box in enumerate(objects, start=1):
        if box is None:
            continue
        bbox = [
            [round(origin_zyx_mm[axis] + section.start * geometry.voxel_size_mm, 2),
             round(origin_zyx_mm[axis] + section.stop * geometry.voxel_size_mm, 2)]
            for axis, section in enumerate(box)
        ]
        report["regions"].append({
            "id": region_id,
            "color_rgb": list(region_color(region_id)),
            "volume_mm3": round(int(kept_counts[region_id]) * geometry.voxel_size_mm ** 3, 2),
            "mean_gray_level": round(float(sums[region_id] / kept_counts[region_id]), 2),
            "bbox_zyx_mm": bbox,
        })
    return normalized, labels, report


def project_labels_to_frames(
    labels: np.ndarray, dsc_frames: np.ndarray,
    origin_zyx_mm: tuple[float, float, float], geometry: SweepGeometry,
    bright_threshold: float, min_frames: int = 1,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Reslice the volume at measured frame angles; no coarse-cell rectangles."""
    geometry.validate(len(dsc_frames))
    if labels.ndim != 3 or labels.dtype != np.uint16:
        raise ValueError("投影需要 uint16 三维标签体。")
    frame_count, height, width = dsc_frames.shape
    spacing = geometry.voxel_size_mm
    outer = geometry.outer_radius_mm
    lateral = geometry.lateral_limit_mm
    x = np.linspace(-lateral, lateral, width, dtype=np.float32)[None, :]
    local_y = np.linspace(0.0, outer, height, dtype=np.float32)[:, None]
    projected = np.zeros(dsc_frames.shape, dtype=np.uint16)
    source = labels.astype(np.float32, copy=False)
    for index, angle in enumerate(geometry.centred_angles_deg):
        radians = math.radians(float(angle))
        world_y = geometry.pivot_depth_mm + (local_y - geometry.pivot_depth_mm) * math.cos(radians)
        world_z = (local_y - geometry.pivot_depth_mm) * math.sin(radians)
        coords = [
            np.broadcast_to((world_z - origin_zyx_mm[0]) / spacing, (height, width)),
            np.broadcast_to((world_y - origin_zyx_mm[1]) / spacing, (height, width)),
            np.broadcast_to((x - origin_zyx_mm[2]) / spacing, (height, width)),
        ]
        projected[index] = ndi.map_coordinates(
            source, coords, order=0, mode="constant", cval=0.0,
            prefilter=False,
        ).astype(np.uint16)
        # Geometry projection is only a proposal. The actual measured frame
        # must have a corresponding bright echo at that location.
        projected[index][dsc_frames[index] < max(100.0, bright_threshold - 9.0)] = 0
        projected[index] = ndi.median_filter(projected[index], size=3)
        if progress and (index % 5 == 0 or index + 1 == frame_count):
            progress((index + 1) / frame_count,
                     f"正在将三维区域回投到图像 {index + 1}/{frame_count}")
    present = np.array([
        np.bincount(frame.ravel(), minlength=int(labels.max()) + 1) > 20
        for frame in projected
    ])
    supported = present.sum(axis=0) >= min_frames
    supported[0] = False
    rejected = np.flatnonzero(~supported)
    if len(rejected):
        drop = np.zeros(int(labels.max()) + 1, dtype=bool)
        drop[rejected] = True
        projected[drop[projected]] = 0
        labels = labels.copy()
        labels[drop[labels]] = 0
    return projected, labels


def _save_binary_ply(path: Path, vertices_zyx: np.ndarray,
                     faces: np.ndarray, color: tuple[int, int, int]) -> None:
    vertices = np.empty(len(vertices_zyx), dtype=[
        ("x", "<f4"), ("y", "<f4"), ("z", "<f4"),
        ("red", "u1"), ("green", "u1"), ("blue", "u1"),
    ])
    vertices["x"] = vertices_zyx[:, 2]
    vertices["y"] = vertices_zyx[:, 1]
    vertices["z"] = vertices_zyx[:, 0]
    vertices["red"], vertices["green"], vertices["blue"] = color
    face_records = np.empty((len(faces), 13), dtype=np.uint8)
    face_records[:, 0] = 3
    face_records[:, 1:] = faces.astype("<i4", copy=False).view(np.uint8).reshape(-1, 12)
    header = (
        "ply\nformat binary_little_endian 1.0\n"
        f"element vertex {len(vertices)}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property uchar red\nproperty uchar green\nproperty uchar blue\n"
        f"element face {len(faces)}\n"
        "property list uchar int vertex_indices\nend_header\n"
    )
    with path.open("wb") as stream:
        stream.write(header.encode("ascii"))
        vertices.tofile(stream)
        face_records.tofile(stream)


def export_volume_result(
    output_dir: Path, stem: str, result: VolumeResult,
    mesh_limit: int = 12,
    progress: Callable[[float, str], None] | None = None,
) -> dict:
    """Save interoperable 3-D label/intensity volumes and top-region meshes."""
    output_dir.mkdir(parents=True, exist_ok=True)
    label_path = output_dir / f"{stem}_volume_labels_u16.raw"
    intensity_path = output_dir / f"{stem}_volume_intensity_u8.raw"
    result.labels.tofile(label_path)
    result.intensity.tofile(intensity_path)
    mesh_dir = output_dir / f"{stem}_region_meshes"
    mesh_dir.mkdir(exist_ok=True)
    objects = ndi.find_objects(result.labels)
    mesh_files = []
    for region_id in range(1, min(len(objects), mesh_limit) + 1):
        box = objects[region_id - 1]
        if box is None:
            continue
        mask = result.labels[box] == region_id
        padded = np.pad(mask, 1, mode="constant")
        try:
            vertices, faces, _, _ = measure.marching_cubes(
                padded.astype(np.float32), level=0.5,
                step_size=2, allow_degenerate=False,
            )
        except (ValueError, RuntimeError):
            continue
        base = np.array([section.start - 1 for section in box], dtype=np.float32)
        vertices = (
            (vertices + base) * result.spacing_mm
            + np.asarray(result.origin_zyx_mm, dtype=np.float32)
        )
        path = mesh_dir / f"region_{region_id:04d}.ply"
        _save_binary_ply(path, vertices, faces, region_color(region_id))
        mesh_files.append(str(path))
        if progress:
            progress(region_id / max(mesh_limit, 1),
                     f"正在生成三维网格 {region_id}/{mesh_limit}")
    metadata = dict(result.report)
    metadata.update({
        "storage_order": "[z, y, x] row-major little-endian",
        "label_dtype": "uint16",
        "intensity_dtype": "uint8",
        "label_file": str(label_path),
        "intensity_file": str(intensity_path),
        "mesh_files": mesh_files,
        "projected_label_shape": list(result.projected_labels.shape),
    })
    metadata_path = output_dir / f"{stem}_volume_segmentation.json"
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"volume_metadata": str(metadata_path), "mesh_folder": str(mesh_dir),
            "mesh_count": len(mesh_files)}


def full_volume_region_pipeline(
    dsc_frames: np.ndarray, geometry: SweepGeometry, *,
    bright_reference: float = 145.0, brightness_tolerance: float = 30.0,
    gradient_limit: float = 90.0, max_regions: int = 256,
    min_frames: int = 1, radial_shadow_strength: float = 0.75,
    min_brightness_gap: float = 28.0,
    contour_params: ContourParams | None = None,
    progress: Callable[[float, str], None] | None = None,
) -> VolumeResult:
    def stage(start, width):
        return (lambda fraction, message: progress(start + width * fraction, message)
                if progress else None)

    if contour_params is None:
        contour_params = ContourParams()
    feature_frames, shadow_report = suppress_radial_shadows(
        dsc_frames, geometry, radial_shadow_strength,
    )
    closed_masks, contour_report = analyze_sequence(
        feature_frames, contour_params, bright_reference,
        np.asarray(geometry.frame_angles_deg), progress=stage(0.0, 0.36),
    )
    volume, origin = reconstruct_volume(feature_frames, geometry, stage(0.36, 0.20))
    contour_volume, contour_origin = reconstruct_volume(
        closed_masks, geometry, stage(0.56, 0.18),
    )
    if contour_origin != origin:
        raise ValueError("闭合轮廓体与亮度体的重建原点不一致。")
    normalized, labels, report = segment_volume(
        volume, origin, geometry,
        bright_reference=bright_reference,
        brightness_tolerance=brightness_tolerance,
        gradient_limit=gradient_limit,
        min_brightness_gap=min_brightness_gap,
        contour_volume=contour_volume,
        max_regions=max_regions,
        progress=stage(0.74, 0.18),
    )
    projected, labels = project_labels_to_frames(
        labels, dsc_frames, origin, geometry,
        report["effective_bright_threshold"], min_frames=min_frames,
        progress=stage(0.92, 0.08),
    )
    report["projected_nonzero_pixels"] = int(np.count_nonzero(projected))
    report["radial_shadow_feature_repair"] = shadow_report
    report["edge_contour_pipeline"] = contour_report
    report["bright_pixel_coverage_percent"] = round(
        100.0 * float(np.count_nonzero(projected))
        / max(int(np.count_nonzero(dsc_frames >= report["effective_bright_threshold"])), 1),
        2,
    )
    report["region_count_after_min_frames"] = int(np.unique(labels).size - 1)
    report["geometry"] = {
        "sweep_axis_assumption": "lateral x-axis in DSC plane",
        "pivot_depth_mm": geometry.pivot_depth_mm,
        "sample_scale_mm": geometry.sample_scale_mm,
        "scan_angle_deg": geometry.scan_angle_deg,
        "angle3d_first_last_deg": [float(geometry.frame_angles_deg[0]),
                                   float(geometry.frame_angles_deg[-1])],
    }
    return VolumeResult(normalized, labels, projected, origin,
                        geometry.voxel_size_mm, report)
