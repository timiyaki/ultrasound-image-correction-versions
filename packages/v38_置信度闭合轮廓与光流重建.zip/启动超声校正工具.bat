@echo off
setlocal
cd /d "%~dp0"
set "PYEXE=C:\Users\timiy\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "SCRIPT=%~dp0ultrasound_bin_gui.py"
if not exist "%SCRIPT%" goto missing_script
if not exist "%PYEXE%" set "PYEXE=python"
if /I "%~1"=="--check" goto check_environment
goto bundled_python
:check_environment
"%PYEXE%" -c "import numpy, PIL, tkinter, scipy, skimage; print('Environment OK')"
goto finished
:bundled_python
"%PYEXE%" -c "import numpy, PIL, tkinter, scipy, skimage" >nul 2>&1
if errorlevel 1 (
  echo Installing required Python packages...
  "%PYEXE%" -m pip install -r "%~dp0requirements.txt"
  if errorlevel 1 goto missing_python
)
"%PYEXE%" "%SCRIPT%"
goto finished
:missing_python
echo ERROR: configured Python was not found.
set "APP_ERROR=1"
goto finished
:missing_script
echo ERROR: ultrasound_bin_gui.py was not found in this folder.
set "APP_ERROR=1"
:finished
if errorlevel 1 set "APP_ERROR=1"
if defined APP_ERROR pause
endlocal
