"""Confidence-gated closed contours and optical-flow temporal support.

The module analyzes a reduced-resolution *copy* of corrected DSC images.
Neither Chan-Vese nor optical flow modifies the grayscale output frames.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from PIL import Image
from scipy import ndimage as ndi
from skimage import feature, filters, morphology, registration, segmentation


GREEN = (40, 255, 80)


@dataclass(frozen=True)
class ContourParams:
    working_width: int = 256
    canny_sigma: float = 1.2
    confidence_threshold: float | None = None  # None = frame-adaptive
    closing_radius: int = 2
    chan_vese_iterations: int = 4
    flow_strength: float = 0.45

    def validate(self) -> None:
        if not 96 <= self.working_width <= 512:
            raise ValueError("轮廓工作宽度应在 96–512 像素之间。")
        if not 0.5 <= self.canny_sigma <= 3.0:
            raise ValueError("Canny 平滑半径应在 0.5–3.0 之间。")
        if self.confidence_threshold is not None and not 0.05 <= self.confidence_threshold <= 0.95:
            raise ValueError("边缘置信度阈值应在 0.05–0.95 之间。")
        if not 1 <= self.closing_radius <= 5:
            raise ValueError("闭运算半径应在 1–5 像素之间。")
        if not 0 <= self.chan_vese_iterations <= 20:
            raise ValueError("Chan–Vese 迭代次数应在 0–20 之间。")
        if not 0.0 <= self.flow_strength <= 1.0:
            raise ValueError("光流连续性强度应在 0–1 之间。")


@dataclass
class FrameContours:
    gray: np.ndarray
    confidence: np.ndarray
    candidate_edges: np.ndarray
    reliable_edges: np.ndarray
    closed_edges: np.ndarray
    mask: np.ndarray
    contour: np.ndarray
    scan_mask: np.ndarray
    report: dict


def _resize_gray(frame: np.ndarray, target_width: int) -> np.ndarray:
    if frame.ndim != 2 or frame.dtype != np.uint8:
        raise ValueError("轮廓输入必须是二维 uint8 灰度图。")
    height, width = frame.shape
    target_width = min(width, target_width)
    target_height = max(1, round(height * target_width / width))
    if (target_height, target_width) == frame.shape:
        return frame.astype(np.float32) / 255.0
    resized = Image.fromarray(frame).resize(
        (target_width, target_height), Image.Resampling.BILINEAR,
    )
    return np.asarray(resized, dtype=np.float32) / 255.0


def _scan_mask(gray: np.ndarray) -> np.ndarray:
    support = ndi.maximum_filter(gray, size=7) > (5.0 / 255.0)
    support = ndi.binary_fill_holes(support)
    return ndi.binary_erosion(support, iterations=2)


def analyze_frame(
    frame: np.ndarray, params: ContourParams,
    bright_reference: float = 145.0,
) -> FrameContours:
    """Scharr → Canny → local statistics → confidence → closing → Chan-Vese."""
    params.validate()
    gray = _resize_gray(frame, params.working_width)
    scan = _scan_mask(gray)
    empty = np.zeros(gray.shape, dtype=bool)
    if np.count_nonzero(scan) < 100:
        return FrameContours(gray, gray.copy(), empty, empty, empty,
                             empty, empty, scan,
                             {"candidate_pixels": 0, "reliable_pixels": 0,
                              "confidence_threshold": 1.0, "closed_pixels": 0,
                              "active_area": 0})
    smoothed = ndi.gaussian_filter(gray, sigma=0.8)
    scharr = filters.scharr(smoothed)
    candidates = feature.canny(
        smoothed, sigma=params.canny_sigma,
        low_threshold=0.55, high_threshold=0.82,
        use_quantiles=True, mask=scan,
    )

    # A coherent gray-level transition has a directional local structure;
    # isolated speckle usually does not. Include local contrast and variance
    # so strong but noisy Canny pixels can be rejected independently.
    dy = ndi.sobel(smoothed, axis=0) / 8.0
    dx = ndi.sobel(smoothed, axis=1) / 8.0
    jyy = ndi.gaussian_filter(dy * dy, 2.0)
    jxx = ndi.gaussian_filter(dx * dx, 2.0)
    jxy = ndi.gaussian_filter(dx * dy, 2.0)
    coherence = np.sqrt((jxx - jyy) ** 2 + 4.0 * jxy ** 2) / (jxx + jyy + 1e-5)
    mean = ndi.uniform_filter(smoothed, size=7)
    variance = np.maximum(ndi.uniform_filter(smoothed * smoothed, size=7) - mean * mean, 0.0)
    local_std = np.sqrt(variance)
    contrast = ndi.maximum_filter(smoothed, size=5) - ndi.minimum_filter(smoothed, size=5)
    gradient_scale = max(float(np.percentile(scharr[scan], 88)), 0.015)
    gradient_score = np.clip(scharr / gradient_scale, 0.0, 1.0)
    contrast_score = np.clip(contrast / (local_std + 0.035), 0.0, 1.0)
    confidence = np.clip(
        0.52 * gradient_score + 0.34 * coherence + 0.14 * contrast_score,
        0.0, 1.0,
    ).astype(np.float32)
    confidence[~scan] = 0.0
    threshold = (float(np.clip(np.percentile(confidence[candidates], 48), 0.38, 0.72))
                 if params.confidence_threshold is None and np.any(candidates)
                 else (params.confidence_threshold or 0.5))
    reliable = candidates & (confidence >= threshold)
    reliable = morphology.remove_small_objects(reliable, min_size=4, connectivity=2)
    closed = morphology.binary_closing(reliable, footprint=morphology.disk(params.closing_radius))
    closed &= scan
    closed = morphology.remove_small_objects(closed, min_size=6, connectivity=2)

    # The candidate edge image guides the initialization; Chan-Vese then
    # closes boundaries from regional gray statistics rather than just
    # drawing Canny's open arcs. Constrain growth to nearby echo material.
    floor = float(np.clip(bright_reference - 38.0, 65.0, 190.0)) / 255.0
    seed = (smoothed >= floor) & scan
    seed = morphology.binary_closing(seed, footprint=morphology.disk(params.closing_radius))
    seed = morphology.remove_small_objects(seed, min_size=18, connectivity=2)
    seed &= ~closed
    if params.chan_vese_iterations and np.count_nonzero(seed) >= 20:
        active = segmentation.morphological_chan_vese(
            smoothed, num_iter=params.chan_vese_iterations,
            init_level_set=seed, smoothing=1,
        ).astype(bool)
    else:
        active = seed.copy()
    neighborhood = ndi.binary_dilation(seed, iterations=5 + params.closing_radius)
    active &= scan & neighborhood & (smoothed >= max(floor - 0.13, 0.13))
    active = morphology.binary_closing(active, footprint=morphology.disk(1))
    active = morphology.remove_small_objects(active, min_size=20, connectivity=2)
    contour = active & ~ndi.binary_erosion(active, iterations=1)
    return FrameContours(gray, confidence, candidates, reliable, closed,
                         active, contour, scan, {
                             "candidate_pixels": int(np.count_nonzero(candidates)),
                             "reliable_pixels": int(np.count_nonzero(reliable)),
                             "confidence_threshold": round(float(threshold), 3),
                             "closed_pixels": int(np.count_nonzero(closed)),
                             "active_area": int(np.count_nonzero(active)),
                             "chan_vese_used": bool(params.chan_vese_iterations and
                                                     np.count_nonzero(seed) >= 20),
                             "closed_contour_pixels": int(np.count_nonzero(contour)),
                         })


def _resize_binary(mask: np.ndarray, target_shape: tuple[int, int]) -> np.ndarray:
    if mask.shape == target_shape:
        return mask.copy()
    image = Image.fromarray(mask.astype(np.uint8) * 255).resize(
        (target_shape[1], target_shape[0]), Image.Resampling.NEAREST,
    )
    return np.asarray(image) > 0


def add_closed_contours(
    frame: np.ndarray, params: ContourParams,
    bright_reference: float = 145.0,
) -> tuple[np.ndarray, float]:
    analysis = analyze_frame(frame, params, bright_reference)
    full_mask = _resize_binary(analysis.mask, frame.shape[:2])
    contour = full_mask & ~ndi.binary_erosion(full_mask, iterations=1)
    if frame.ndim == 2:
        rgb = np.repeat(frame[..., None], 3, axis=2)
    else:
        rgb = frame.copy()
    rgb[contour] = GREEN
    return rgb, float(analysis.report["confidence_threshold"])


def analyze_sequence(
    frames: np.ndarray, params: ContourParams,
    bright_reference: float, angles_deg: np.ndarray,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, dict]:
    """Link closed masks across adjacent measured frames with dense iLK flow."""
    if frames.ndim != 3 or frames.dtype != np.uint8:
        raise ValueError("跨帧轮廓输入必须是 [帧, 高, 宽] uint8 图像。")
    if len(frames) == 0:
        raise ValueError("跨帧轮廓至少需要一帧图像。")
    if len(angles_deg) != len(frames):
        raise ValueError("跨帧光流需要每帧角度。")
    analyses = []
    for index, frame in enumerate(frames):
        analyses.append(analyze_frame(frame, params, bright_reference))
        if progress and (index % 8 == 0 or index + 1 == len(frames)):
            progress(0.55 * (index + 1) / len(frames),
                     f"Scharr/Canny/Chan–Vese {index + 1}/{len(frames)}")
    masks = np.stack([item.mask for item in analyses])
    flow_pairs = 0
    propagated_pixels = 0
    if params.flow_strength > 0 and len(frames) > 1:
        steps = np.abs(np.diff(np.asarray(angles_deg, dtype=float)))
        max_step = max(8.0, 3.0 * float(np.median(steps)))
        rows, cols = np.meshgrid(
            np.arange(masks.shape[1], dtype=np.float32),
            np.arange(masks.shape[2], dtype=np.float32), indexing="ij",
        )
        for index in range(1, len(frames)):
            if steps[index - 1] > max_step:
                continue
            previous = analyses[index - 1]
            current = analyses[index]
            flow = registration.optical_flow_ilk(
                current.gray, previous.gray, radius=5, num_warp=2,
                gaussian=True, dtype=np.float32,
            )
            warped = ndi.map_coordinates(
                masks[index - 1].astype(np.float32),
                [rows + flow[0], cols + flow[1]],
                order=0, mode="constant", cval=0.0, prefilter=False,
            ) > 0.5
            nearby = ndi.binary_dilation(masks[index], iterations=max(1, round(4 * params.flow_strength)))
            gray_floor = float(np.clip(bright_reference - 52.0, 60.0, 180.0)) / 255.0
            addition = (warped & nearby & current.scan_mask
                        & (current.gray >= gray_floor)
                        & ~current.closed_edges)
            added = int(np.count_nonzero(addition & ~masks[index]))
            masks[index] |= addition
            masks[index] = morphology.binary_closing(masks[index], footprint=morphology.disk(1))
            propagated_pixels += added
            flow_pairs += 1
            if progress and (index % 8 == 0 or index + 1 == len(frames)):
                progress(0.55 + 0.45 * (index + 1) / len(frames),
                         f"光流跨帧衔接 {index + 1}/{len(frames)}")
    return masks.astype(np.uint8) * 255, {
        "algorithm": "Scharr, Canny, local gray/texture confidence, morphology, morphological Chan-Vese, dense iLK optical flow",
        "working_shape": list(masks.shape[1:]),
        "frame_count": len(frames),
        "mean_candidate_edge_pixels": round(float(np.mean([item.report["candidate_pixels"] for item in analyses])), 1),
        "mean_reliable_edge_pixels": round(float(np.mean([item.report["reliable_pixels"] for item in analyses])), 1),
        "mean_closed_contour_area": round(float(np.mean([np.count_nonzero(frame) for frame in masks])), 1),
        "chan_vese_frames": sum(bool(item.report["chan_vese_used"]) for item in analyses),
        "mean_closed_contour_pixels": round(float(np.mean([
            item.report["closed_contour_pixels"] for item in analyses
        ])), 1),
        "mean_confidence_threshold": round(float(np.mean([item.report["confidence_threshold"] for item in analyses])), 3),
        "flow_pairs": flow_pairs,
        "flow_added_pixels": propagated_pixels,
    }
