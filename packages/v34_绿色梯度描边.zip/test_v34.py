"""Green gradient contour regression checks for Image v34."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from gradient_outline_v34 import GREEN, add_green_gradient_outline, gradient_outline_mask
from temporal_regions_v33 import add_region_overlay
from ultrasound_bin_gui import ProcessParams, export_results


class V34Tests(unittest.TestCase):
    @staticmethod
    def frame() -> np.ndarray:
        frame = np.zeros((80, 120), dtype=np.uint8)
        frame[8:72, 8:112] = 50
        frame[20:60, 60:100] = 210
        return frame

    def test_draws_inner_brightness_step_not_outer_scan_border(self):
        mask, threshold = gradient_outline_mask(self.frame())
        self.assertGreater(threshold, 0)
        self.assertGreater(int(mask[22:58, 58:63].sum()), 20)
        self.assertEqual(int(mask[:, 6:11].sum()), 0)
        self.assertEqual(int(mask[25:55, 25:45].sum()), 0)

    def test_manual_threshold_changes_amount_and_color_is_only_green(self):
        low, _ = gradient_outline_mask(self.frame(), threshold=5)
        high, _ = gradient_outline_mask(self.frame(), threshold=100)
        self.assertGreater(int(low.sum()), int(high.sum()))
        rgb, _ = add_green_gradient_outline(self.frame(), threshold=20)
        colored = np.any(rgb[..., :1] != rgb[..., 1:2], axis=2)
        self.assertGreater(int(colored.sum()), 0)
        self.assertTrue(np.all(rgb[colored] == np.asarray(GREEN)))

    def test_region_fill_does_not_replace_green_line_or_add_colored_border(self):
        frame = self.frame()
        rgb, _ = add_green_gradient_outline(frame, threshold=20)
        green = np.all(rgb == np.asarray(GREEN), axis=2)
        labels = np.zeros(frame.shape, dtype=np.uint16)
        labels[20:60, 60:100] = 1
        overlaid = add_region_overlay(rgb, labels)
        self.assertTrue(np.all(overlaid[green] == np.asarray(GREEN)))
        self.assertGreater(int(np.any(overlaid[30:50, 70:90] !=
                                      frame[30:50, 70:90, None], axis=2).sum()), 0)

    def test_export_uses_green_in_png_and_preserves_grayscale_bin(self):
        frames = np.stack([self.frame(), self.frame()], axis=0)
        params = ProcessParams(width=120, height=80, gradient_outline_auto=False,
                               gradient_outline_threshold=20)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            gray_bin, png_dir, comparison = export_results(
                Path("raw_frames_u8.bin"), root, frames, frames, {}, params,
            )
            np.testing.assert_array_equal(
                np.fromfile(gray_bin, dtype=np.uint8).reshape(frames.shape), frames,
            )
            with Image.open(png_dir / "frame_0001.png") as image:
                rgb = np.asarray(image)
            green = np.all(rgb == np.asarray(GREEN), axis=2)
            self.assertGreater(int(green.sum()), 20)
            self.assertTrue(comparison.is_file())
            meta = json.loads(
                (root / "raw_frames_u8_processing.json").read_text(encoding="utf-8")
            )
            self.assertIn("green_gradient_outline", meta)
            self.assertNotIn("red_outline_overlay", meta)
            self.assertEqual(meta["green_gradient_outline"]["effective_frame_thresholds"],
                             [20.0, 20.0])


if __name__ == "__main__":
    unittest.main()
