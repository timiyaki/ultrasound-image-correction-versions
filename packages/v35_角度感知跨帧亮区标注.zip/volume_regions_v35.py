"""v35: group-adaptive brightness layers and 26-neighbour volume labels.

This is an angle-aware frame lattice, not a calibrated physical 3-D volume.
It uses no machine-learning model and does not create a 3-D mesh.
"""

from __future__ import annotations

import colorsys
import math
from typing import Callable

import numpy as np
from PIL import Image, ImageFilter

from adaptive_edge_v30 import prepare_adaptive_edge_response


def region_color(region_id: int) -> tuple[int, int, int]:
    """Return a reproducible, high-saturation color for a persistent label."""
    if region_id < 1:
        raise ValueError("Region IDs begin at one")
    hue = (0.10 + (region_id - 1) * 0.61803398875) % 1.0
    rgb = colorsys.hsv_to_rgb(hue, 0.87, 1.0)
    return tuple(round(channel * 255) for channel in rgb)


def _scan_interior(frame: np.ndarray) -> np.ndarray:
    """Keep the scan footprint but not the black canvas or outer flare band."""
    active = frame > 0
    footprint = np.zeros_like(active)
    for row in range(frame.shape[0]):
        columns = np.flatnonzero(active[row])
        if columns.size:
            footprint[row, columns[0]:columns[-1] + 1] = True
    safe = footprint
    margin = max(1, round(min(frame.shape) * 0.015))
    for _ in range(margin):
        inner = np.zeros_like(safe)
        inner[1:-1, 1:-1] = (
            safe[1:-1, 1:-1] & safe[:-2, 1:-1] & safe[2:, 1:-1]
            & safe[1:-1, :-2] & safe[1:-1, 2:]
        )
        safe = inner
    return safe & (frame >= 8)


def _edge_guided_diffusion(
    luma: np.ndarray, valid: np.ndarray, response: np.ndarray,
    iterations: int, conductance: float,
    temporal_links: np.ndarray | None = None,
) -> np.ndarray:
    """Stable 3-D Perona–Malik-style diffusion on the coarse scan grid.

    Spatial flux is attenuated by the v31 directional edge response.  A small
    temporal flux smooths matching neighboring frames without erasing motion.
    The final image pipeline is untouched; this only supplies graph features.
    """
    state = luma.astype(np.float32)
    edge = np.abs(response)
    for _ in range(iterations):
        change = np.zeros_like(state)
        for axis in (1, 2):
            first = [slice(None)] * 3
            second = [slice(None)] * 3
            first[axis] = slice(None, -1)
            second[axis] = slice(1, None)
            first = tuple(first)
            second = tuple(second)
            delta = state[second] - state[first]
            barrier = np.maximum(edge[first], edge[second])
            weight = np.exp(-np.square(delta / conductance))
            weight *= np.exp(-np.square(barrier / (conductance * 0.8)))
            weight *= valid[first] & valid[second]
            flux = weight * delta
            change[first] += flux
            change[second] -= flux
        if len(state) > 1:
            delta = state[1:] - state[:-1]
            weight = np.exp(-np.square(delta / conductance))
            weight *= valid[1:] & valid[:-1]
            if temporal_links is not None:
                weight *= temporal_links[:, None, None]
            flux = 0.25 * weight * delta
            change[:-1] += flux
            change[1:] -= flux
        state = np.clip(state + 0.18 * change, 0.0, 255.0)
    return np.rint(state).astype(np.uint8)


def _multi_otsu_thresholds(values: np.ndarray) -> tuple[int, int]:
    """Three-class Otsu on scan-only gray levels, with no external dependency."""
    hist = np.bincount(values.ravel(), minlength=256).astype(np.float64)
    if hist.sum() == 0 or np.count_nonzero(hist) < 3:
        return 80, 145
    probability = hist / hist.sum()
    omega = np.cumsum(probability)
    weighted = np.cumsum(probability * np.arange(256))
    global_mean = weighted[-1]
    best_score = -1.0
    best = (80, 145)
    for first in range(1, 254):
        second = np.arange(first + 1, 255)
        w0 = omega[first]
        w1 = omega[second] - omega[first]
        w2 = 1.0 - omega[second]
        good = (w0 > 1e-8) & (w1 > 1e-8) & (w2 > 1e-8)
        if not np.any(good):
            continue
        mu0 = weighted[first] / w0
        mu1 = np.divide(weighted[second] - weighted[first], w1,
                        out=np.zeros_like(w1), where=good)
        mu2 = np.divide(weighted[-1] - weighted[second], w2,
                        out=np.zeros_like(w2), where=good)
        scores = (w0 * (mu0 - global_mean) ** 2
                  + w1 * (mu1 - global_mean) ** 2
                  + w2 * (mu2 - global_mean) ** 2)
        scores[~good] = -1.0
        at = int(np.argmax(scores))
        if scores[at] > best_score:
            best_score = float(scores[at])
            best = (first, int(second[at]))
    return best


def _angle_links(frame_count: int, frame_angles_deg) -> tuple[np.ndarray, dict]:
    if frame_angles_deg is None:
        return np.ones(max(0, frame_count - 1), dtype=bool), {
            "mode": "ordered-frame-lattice; angle metadata unavailable",
            "linked_neighbor_pairs": max(0, frame_count - 1),
        }
    angles = np.asarray(frame_angles_deg, dtype=np.float64)
    if angles.shape != (frame_count,) or not np.all(np.isfinite(angles)):
        return np.ones(max(0, frame_count - 1), dtype=bool), {
            "mode": "ordered-frame-lattice; angle metadata incomplete",
            "linked_neighbor_pairs": max(0, frame_count - 1),
        }
    raw_delta = np.abs(np.diff(angles)) % 360.0
    delta = np.minimum(raw_delta, 360.0 - raw_delta)
    positive = delta[delta > 0.01]
    typical = float(np.median(positive)) if positive.size else 0.0
    maximum = min(10.0, max(1.5, 2.5 * typical))
    links = delta <= maximum
    return links, {
        "mode": "angle-aware ordered-frame-lattice (not physical 3-D reconstruction)",
        "typical_step_degrees": round(typical, 3),
        "maximum_link_step_degrees": round(maximum, 3),
        "linked_neighbor_pairs": int(links.sum()),
        "rejected_neighbor_pairs": int((~links).sum()),
    }


def _shift_bool(volume: np.ndarray, dz: int, dy: int, dx: int) -> np.ndarray:
    out = np.zeros_like(volume)
    shape = volume.shape
    source = tuple(slice(max(0, -d), min(n, n - d))
                   for d, n in zip((dz, dy, dx), shape))
    target = tuple(slice(max(0, d), min(n, n + d))
                   for d, n in zip((dz, dy, dx), shape))
    out[target] = volume[source]
    return out


def _close_small_gaps(
    candidate: np.ndarray, scan: np.ndarray, luma: np.ndarray,
    threshold: float, tolerance: float, temporal_links: np.ndarray,
) -> np.ndarray:
    """One 6-neighbour 3-D closing pass; admit only reasonably bright bridges."""
    offsets = ((0, 0, 0), (0, -1, 0), (0, 1, 0),
               (0, 0, -1), (0, 0, 1), (-1, 0, 0), (1, 0, 0))
    dilated = np.zeros_like(candidate)
    for dz, dy, dx in offsets:
        shifted = _shift_bool(candidate, dz, dy, dx)
        if dz == 1:
            shifted[1:] &= temporal_links[:, None, None]
        elif dz == -1:
            shifted[:-1] &= temporal_links[:, None, None]
        dilated |= shifted
    closed = np.ones_like(candidate)
    for dz, dy, dx in offsets:
        shifted = _shift_bool(dilated, dz, dy, dx)
        if dz == 1:
            shifted[1:] |= ~temporal_links[:, None, None]
        elif dz == -1:
            shifted[:-1] |= ~temporal_links[:, None, None]
        closed &= shifted
    bridges = (closed & scan & (luma >= threshold - tolerance * 0.35))
    return candidate | bridges


def _union_find_nodes(luma: np.ndarray, valid: np.ndarray, tolerance: float):
    count = luma.size
    parent = np.arange(count, dtype=np.int32)
    size = np.ones(count, dtype=np.int32)
    minimum = luma.ravel().copy()
    maximum = luma.ravel().copy()
    allowed_range = min(255.0, float(tolerance) * 2.0)

    def find(node: int) -> int:
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = int(parent[node])
        return node

    def join(a: int, b: int) -> None:
        root_a, root_b = find(a), find(b)
        if root_a == root_b:
            return
        low = min(int(minimum[root_a]), int(minimum[root_b]))
        high = max(int(maximum[root_a]), int(maximum[root_b]))
        if high - low > allowed_range:
            return
        if size[root_a] < size[root_b]:
            root_a, root_b = root_b, root_a
        parent[root_b] = root_a
        size[root_a] += size[root_b]
        minimum[root_a] = low
        maximum[root_a] = high

    return parent, find, join


def segment_temporal_regions(
    frames: np.ndarray,
    *,
    frame_angles_deg=None,
    bright_threshold: float = 145.0,
    brightness_tolerance: float = 55.0,
    gradient_limit: float = 90.0,
    min_frames: int = 1,
    cell_size: int = 8,
    max_regions: int = 256,
    min_area_pixels: int = 16,
    diffusion_iterations: int = 6,
    diffusion_conductance: float = 42.0,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[np.ndarray, dict]:
    """Label persistent bright areas on an angle-aware 3-D frame lattice.

    Label zero is unselected.  Positive IDs refer to the same connected
    region in every frame, not merely to the same brightness class.  The
    returned labels are full resolution; graph decisions are made on square
    cells of roughly ``cell_size`` source pixels for speed.
    """
    if frames.ndim != 3 or frames.dtype != np.uint8 or not len(frames):
        raise ValueError("需要非空的 [帧, 高, 宽] uint8 灰度序列。")
    if not 4 <= cell_size <= 16:
        raise ValueError("区域网格大小应在 4–16 像素之间。")
    if not 100 <= bright_threshold <= 240:
        raise ValueError("高亮区域下限应在 100–240 灰阶之间。")
    if not 4 <= brightness_tolerance <= 80 or not 8 <= gradient_limit <= 120:
        raise ValueError("亮度相似度或梯度阻断阈值超出范围。")
    if not 1 <= min_frames <= len(frames):
        raise ValueError("最少连续帧数应在 1 和实际帧数之间。")
    if not 1 <= max_regions <= 512:
        raise ValueError("区域数量应在 1–512 之间。")
    if not 16 <= min_area_pixels <= 100000:
        raise ValueError("最小区域面积应在 16–100000 像素之间。")
    if not 0 <= diffusion_iterations <= 12:
        raise ValueError("扩散次数应在 0–12 之间。")
    if not 8 <= diffusion_conductance <= 80:
        raise ValueError("扩散导通尺度应在 8–80 灰阶之间。")

    frame_count, height, width = frames.shape
    grid_h = math.ceil(height / cell_size)
    grid_w = math.ceil(width / cell_size)
    nodes_per_frame = grid_h * grid_w
    node_count = frame_count * nodes_per_frame
    if node_count > 2_000_000:
        raise ValueError("区域网格过大；请增大网格大小以控制内存和处理时间。")

    luma = np.empty((frame_count, grid_h, grid_w), dtype=np.uint8)
    valid = np.empty_like(luma, dtype=bool)
    response = np.empty_like(luma, dtype=np.float32)
    for index, frame in enumerate(frames):
        coarse = np.asarray(
            Image.fromarray(frame, mode="L").resize(
                (grid_w, grid_h), Image.Resampling.BOX
            )
        )
        # A small median in graph space suppresses isolated speckle without
        # modifying the exported image or washing out a step boundary.
        luma[index] = np.asarray(
            Image.fromarray(coarse, mode="L").filter(ImageFilter.MedianFilter(3))
        )
        valid[index] = _scan_interior(coarse)
        # This is the same directional, halo-limited edge response used by v31.
        response[index] = np.abs(prepare_adaptive_edge_response(luma[index]))
        if progress and (index % 8 == 0 or index + 1 == frame_count):
            progress(0.20 * (index + 1) / frame_count,
                     f"正在计算亮度和 v31 边缘 {index + 1}/{frame_count} 帧")

    temporal_links, angle_report = _angle_links(frame_count, frame_angles_deg)
    if diffusion_iterations:
        luma = _edge_guided_diffusion(
            luma, valid, response, diffusion_iterations, diffusion_conductance,
            temporal_links=temporal_links,
        )
    otsu_low, otsu_high = _multi_otsu_thresholds(luma[valid])
    effective_bright = float(np.clip(
        0.7 * bright_threshold + 0.3 * otsu_high, 100.0, 240.0,
    ))
    occupancy = np.empty_like(luma, dtype=np.uint8)
    for index, frame in enumerate(frames):
        occupancy[index] = np.asarray(
            Image.fromarray((frame >= effective_bright).astype(np.uint8) * 255).resize(
                (grid_w, grid_h), Image.Resampling.BOX
            )
        )
    scan_valid = valid.copy()
    # Cells containing a bright sliver are candidates, even if their mean is
    # modest. Closing bridges only small gaps that are still fairly bright.
    valid &= occupancy >= 26
    valid = _close_small_gaps(
        valid, scan_valid, luma, effective_bright,
        brightness_tolerance, temporal_links,
    )
    if progress:
        progress(0.30, "已完成多级亮度分层和三维小间隙修补，正在连接亮区")

    parent, find, join = _union_find_nodes(luma, valid, brightness_tolerance)
    node_ids = np.arange(node_count, dtype=np.int32).reshape(luma.shape)

    # Four unique spatial offsets plus nine next-frame offsets give the full
    # 26-neighbour 3-D adjacency.  Angle jumps disable temporal edges.
    offsets = [(0, 0, 1), (0, 1, -1), (0, 1, 0), (0, 1, 1)]
    offsets += [(1, dy, dx) for dy in (-1, 0, 1) for dx in (-1, 0, 1)]
    for offset_index, (dz, dy, dx) in enumerate(offsets):
        axes = (dz, dy, dx)
        source_slices = tuple(
            slice(max(0, -d), min(n, n - d))
            for d, n in zip(axes, luma.shape)
        )
        target_slices = tuple(
            slice(max(0, d), min(n, n + d))
            for d, n in zip(axes, luma.shape)
        )
        first = luma[source_slices]
        second = luma[target_slices]
        difference = np.abs(first.astype(np.int16) - second.astype(np.int16))
        barrier = difference + 0.8 * np.maximum(
            response[source_slices], response[target_slices],
        )
        allowed = (
            valid[source_slices] & valid[target_slices]
            & (difference <= brightness_tolerance)
            & (barrier <= gradient_limit)
        )
        if dz:
            allowed &= temporal_links[:, None, None]
        for a, b in zip(node_ids[source_slices][allowed],
                        node_ids[target_slices][allowed]):
            join(int(a), int(b))
        if progress:
            progress(0.30 + 0.60 * (offset_index + 1) / len(offsets),
                     f"正在连接三维邻域 {offset_index + 1}/{len(offsets)}")

    flat_valid = np.flatnonzero(valid.ravel())
    root_valid = np.fromiter((find(int(node)) for node in flat_valid),
                             dtype=np.int32, count=len(flat_valid))
    total_cells = np.bincount(root_valid, minlength=node_count)
    frame_index = flat_valid // nodes_per_frame
    pair_key = root_valid.astype(np.int64) * frame_count + frame_index
    unique_pair, cells_per_frame = np.unique(pair_key, return_counts=True)
    root_per_pair = unique_pair // frame_count
    minimum_cells = max(1, math.ceil(min_area_pixels / (cell_size * cell_size)))
    supported_frames = np.bincount(
        root_per_pair[cells_per_frame >= minimum_cells], minlength=node_count,
    )
    candidates = np.flatnonzero(
        (supported_frames >= min_frames)
        & (total_cells >= minimum_cells * min_frames)
    )
    # Require a run of consecutive supported frames.  An area that appears
    # briefly, disappears, and reappears later does not meet the temporal rule.
    persistent = []
    for root in candidates:
        start = np.searchsorted(root_per_pair, root, side="left")
        end = np.searchsorted(root_per_pair, root, side="right")
        nearby_frames = unique_pair[start:end][
            cells_per_frame[start:end] >= minimum_cells
        ] % frame_count
        run = best_run = 1
        for gap in np.diff(nearby_frames):
            run = run + 1 if gap == 1 else 1
            best_run = max(best_run, run)
        if best_run >= min_frames:
            persistent.append(root)
    candidates = np.asarray(persistent, dtype=np.int32)
    if candidates.size:
        score = total_cells[candidates] * np.sqrt(supported_frames[candidates])
        selected = candidates[np.argsort(score)[::-1][:max_regions]]
    else:
        selected = np.empty(0, dtype=np.int32)

    root_to_label = np.zeros(node_count, dtype=np.uint16)
    root_to_label[selected] = np.arange(1, len(selected) + 1, dtype=np.uint16)
    low_labels = np.zeros(node_count, dtype=np.uint16)
    low_labels[flat_valid] = root_to_label[root_valid]
    low_labels = low_labels.reshape(luma.shape)
    labels = np.empty(frames.shape, dtype=np.uint16)
    for index in range(frame_count):
        labels[index] = np.asarray(
            Image.fromarray(low_labels[index].astype(np.int32), mode="I").resize(
                (width, height), Image.Resampling.NEAREST
            ), dtype=np.uint16,
        )
        # A bright coarse cell can contain individual dark pixels.  They must
        # not inherit its color just because nearest-neighbor upsampling did.
        labels[index][frames[index] < effective_bright] = 0
        if progress and (index % 8 == 0 or index + 1 == frame_count):
            progress(0.90 + 0.10 * (index + 1) / frame_count,
                     f"正在生成彩色区域 {index + 1}/{frame_count} 帧")

    brightness_sum = np.bincount(
        root_valid, weights=luma.ravel()[flat_valid], minlength=node_count,
    )
    regions = []
    for label, root in enumerate(selected, start=1):
        pair_mask = (root_per_pair == root) & (cells_per_frame >= minimum_cells)
        frames_present = (unique_pair[pair_mask] % frame_count + 1).tolist()
        regions.append({
            "id": label,
            "color_rgb": list(region_color(label)),
            "mean_gray_level": round(float(brightness_sum[root] / total_cells[root]), 2),
            "coarse_cell_count": int(total_cells[root]),
            "supported_frames_one_based": frames_present,
        })
    return labels, {
        "algorithm": "v35 group multi-Otsu, edge-guided diffusion, guarded 3-D closing and 26-neighbour intensity/gradient graph",
        "bright_threshold_gray_level": float(bright_threshold),
        "effective_bright_threshold_gray_level": round(effective_bright, 2),
        "multi_otsu_thresholds": [otsu_low, otsu_high],
        "angle_adjacency": angle_report,
        "diffusion_iterations": int(diffusion_iterations),
        "diffusion_conductance_gray_levels": float(diffusion_conductance),
        "bright_pixel_coverage_percent": round(
            100.0 * float(np.count_nonzero(labels))
            / max(int(np.count_nonzero(frames >= effective_bright)), 1), 2,
        ),
        "brightness_tolerance": float(brightness_tolerance),
        "gradient_limit": float(gradient_limit),
        "minimum_supported_frames": int(min_frames),
        "minimum_area_pixels_per_supported_frame": int(min_area_pixels),
        "cell_size_pixels": int(cell_size),
        "coarse_shape": list(luma.shape),
        "output_shape": list(labels.shape),
        "region_count": len(regions),
        "regions": regions,
        "note": "Frame-stack connectivity is not physical 3-D reconstruction; labels are not anatomical segmentation or diagnosis.",
    }


def add_region_overlay(
    image: np.ndarray, labels: np.ndarray, alpha: float = 0.36,
) -> np.ndarray:
    """Blend stable region fill colors without adding non-gradient contours."""
    if labels.ndim != 2 or image.shape[:2] != labels.shape:
        raise ValueError("区域标签与当前图像的尺寸不一致。")
    if not 0.0 <= alpha <= 1.0:
        raise ValueError("颜色透明度应在 0–1 之间。")
    rgb = (
        np.repeat(image[..., None], 3, axis=2)
        if image.ndim == 2 else image.copy()
    )
    original_gray = (rgb[..., 0] == rgb[..., 1]) & (rgb[..., 1] == rgb[..., 2])
    for label in np.unique(labels):
        if label == 0:
            continue
        color = np.asarray(region_color(int(label)), dtype=np.float32)
        region = labels == label
        interior = region & original_gray
        rgb[interior] = np.rint(
            (1.0 - alpha) * rgb[interior].astype(np.float32) + alpha * color
        ).astype(np.uint8)
    return rgb
