import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from adaptive_edge_v30 import (
    analyze_edge_frame, apply_adaptive_edge_response,
    prepare_adaptive_edge_response,
)
from ultrasound_bin_gui import (
    PreviewRenderer, ProcessParams, add_diffused_dual_outline,
    diffused_outline_mask, estimate_outline_thresholds, export_results,
    process_frames, resolve_outline_thresholds,
)


class V31Tests(unittest.TestCase):
    def test_red_and_blue_share_contour_algorithm_at_distinct_thresholds(self):
        frame = np.zeros((128, 128), np.uint8)
        frame[7:121, 7:121] = 48
        frame[32:97, 30:99] = 110
        frame[51:78, 51:77] = 205
        result = add_diffused_dual_outline(frame, 90, 165, 3)
        red = np.all(result == (255, 32, 32), axis=2)
        blue = np.all(result == (32, 112, 255), axis=2)
        red_candidate = diffused_outline_mask(frame, 90, 3)
        blue_candidate = diffused_outline_mask(frame, 165, 3)
        self.assertGreater(np.count_nonzero(red[28:101, 26:103]), 30)
        self.assertGreater(np.count_nonzero(blue[48:81, 48:80]), 20)
        self.assertTrue(np.all(red <= red_candidate))
        self.assertTrue(np.all(blue <= blue_candidate))
        self.assertEqual(np.count_nonzero(red[3:13, :]), 0)
        self.assertEqual(np.count_nonzero(blue[3:13, :]), 0)

    def test_auto_thresholds_include_gray_and_separate_bright(self):
        frame = np.full((128, 128), 30, np.uint8)
        frame[12:116, 12:116] = 75
        frame[35:95, 33:97] = 115
        frame[55:80, 53:78] = 195
        red, blue = estimate_outline_thresholds(frame)
        self.assertGreaterEqual(red, 75)
        self.assertLessEqual(red, 160)
        self.assertGreaterEqual(blue, red + 24)

    def test_manual_blue_remains_higher_than_red(self):
        frame = np.full((96, 96), 100, np.uint8)
        params = ProcessParams(outline_auto_enabled=False,
                               red_outline_threshold=125,
                               blue_outline_threshold=100)
        self.assertEqual(resolve_outline_thresholds(frame, params), (125.0, 149.0))

    def test_auto_edge_factor_reacts_to_texture_and_preserves_black(self):
        rng = np.random.default_rng(42)
        clean = np.zeros((96, 96), np.uint8)
        clean[12:84, 12:84] = 80
        clean[34:62, 34:62] = 170
        noisy = clean.copy()
        tile = noisy[12:84, 12:84].astype(np.int16)
        noisy[12:84, 12:84] = np.clip(tile + rng.integers(-24, 25, tile.shape), 1, 245)
        self.assertGreater(analyze_edge_frame(clean)["auto_factor"],
                           analyze_edge_frame(noisy)["auto_factor"])
        response = prepare_adaptive_edge_response(clean)
        result, report = apply_adaptive_edge_response(clean, response, 1.0, True)
        self.assertEqual(int(result[0, 0]), 0)
        self.assertGreater(report["effective_gain"], 0)

    def test_exact_preview_agrees_with_export_pipeline(self):
        raw = np.zeros((2, 48, 64), np.uint8)
        raw[:, 4:44, 4:60] = 65
        raw[:, 17:32, 20:47] = 150
        p = ProcessParams(width=64, height=48, edge_auto_enabled=True)
        expected, _ = process_frames(raw, p)
        _, _, preview, _ = PreviewRenderer().render(raw, 0, p, exact_edges=True)
        np.testing.assert_array_equal(preview, expected[0])

    def test_export_keeps_gray_bin_and_three_comparison_columns(self):
        raw = np.zeros((2, 48, 64), np.uint8)
        raw[:, 4:44, 4:60] = 65
        raw[:, 17:32, 20:47] = 150
        p = ProcessParams(width=64, height=48)
        processed, meta = process_frames(raw, p)
        with tempfile.TemporaryDirectory() as directory:
            bin_path, png_dir, comparison = export_results(
                Path("raw_frames_u8.bin"), Path(directory), raw, processed, meta, p,
            )
            np.testing.assert_array_equal(np.fromfile(bin_path, np.uint8), processed.ravel())
            self.assertTrue((png_dir / "frame_0001.png").is_file())
            with Image.open(comparison) as image:
                self.assertEqual(image.width, 1024)


if __name__ == "__main__":
    unittest.main()
