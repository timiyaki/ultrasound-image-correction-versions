"""One-pixel green contours at significant ultrasound brightness gradients."""

from __future__ import annotations

import numpy as np
from PIL import Image, ImageFilter


GREEN = (40, 255, 80)


def _interior_scan_mask(frame: np.ndarray) -> np.ndarray:
    """Exclude the black canvas and its artificial high-contrast sector edge."""
    active = frame > 0
    footprint = np.zeros_like(active)
    for row in range(frame.shape[0]):
        columns = np.flatnonzero(active[row])
        if columns.size:
            footprint[row, columns[0]:columns[-1] + 1] = True
    margin = max(2, round(min(frame.shape) * 0.01))
    safe = footprint
    for _ in range(margin):
        padded = np.pad(safe, 1, mode="constant")
        safe = (
            safe & padded[:-2, 1:-1] & padded[2:, 1:-1]
            & padded[1:-1, :-2] & padded[1:-1, 2:]
        )
    return safe & active


def _mean3(source: np.ndarray) -> np.ndarray:
    padded = np.pad(source, 1, mode="reflect")
    return sum(
        padded[dy:dy + source.shape[0], dx:dx + source.shape[1]]
        for dy in range(3) for dx in range(3)
    ) / 9.0


def _gradient_features(frame: np.ndarray, smoothing_radius: float):
    blurred = np.asarray(
        Image.fromarray(frame).filter(ImageFilter.GaussianBlur(smoothing_radius)),
        dtype=np.float32,
    )
    gx = np.zeros_like(blurred)
    gy = np.zeros_like(blurred)
    gx[:, 1:-1] = (blurred[:, 2:] - blurred[:, :-2]) * 0.5
    gy[1:-1, :] = (blurred[2:, :] - blurred[:-2, :]) * 0.5
    magnitude = np.hypot(gx, gy)
    jxx = _mean3(gx * gx)
    jyy = _mean3(gy * gy)
    jxy = _mean3(gx * gy)
    coherence = np.sqrt((jxx - jyy) ** 2 + 4.0 * jxy * jxy) / (
        jxx + jyy + 1e-6
    )
    return magnitude, gx, gy, coherence


def _thin_ridge(magnitude: np.ndarray, gx: np.ndarray, gy: np.ndarray) -> np.ndarray:
    """Four-direction nonmaximum suppression keeps approximately one-pixel lines."""
    angle = (np.degrees(np.arctan2(gy, gx)) + 180.0) % 180.0
    padded = np.pad(magnitude, 1, mode="constant")
    height, width = magnitude.shape
    directions = (
        ((angle < 22.5) | (angle >= 157.5), (0, -1), (0, 1)),
        ((angle >= 22.5) & (angle < 67.5), (-1, -1), (1, 1)),
        ((angle >= 67.5) & (angle < 112.5), (-1, 0), (1, 0)),
        ((angle >= 112.5) & (angle < 157.5), (-1, 1), (1, -1)),
    )
    peak = np.zeros_like(magnitude, dtype=bool)
    for direction, first, second in directions:
        y1, x1 = first
        y2, x2 = second
        before = padded[1 + y1:1 + y1 + height, 1 + x1:1 + x1 + width]
        after = padded[1 + y2:1 + y2 + height, 1 + x2:1 + x2 + width]
        peak |= direction & (magnitude >= before) & (magnitude > after)
    return peak


def gradient_outline_mask(
    frame: np.ndarray,
    threshold: float | None = None,
    smoothing_radius: float = 1.4,
) -> tuple[np.ndarray, float]:
    """Find coherent, locally maximal brightness gradients inside the scan."""
    if frame.ndim != 2 or frame.dtype != np.uint8:
        raise ValueError("梯度描边需要二维 uint8 灰度图像。")
    if not 0.5 <= smoothing_radius <= 3.0:
        raise ValueError("平滑半径应在 0.5–3.0 像素之间。")
    if threshold is not None and not 5.0 <= threshold <= 100.0:
        raise ValueError("手动梯度阈值应在 5–100 之间。")
    safe = _interior_scan_mask(frame)
    magnitude, gx, gy, coherence = _gradient_features(frame, smoothing_radius)
    values = magnitude[safe]
    effective = (
        float(np.clip(np.percentile(values, 96), 12.0, 85.0))
        if threshold is None and values.size >= 32
        else (24.0 if threshold is None else float(threshold))
    )
    outline = (
        _thin_ridge(magnitude, gx, gy)
        & (magnitude >= effective)
        & (coherence >= 0.30)
        & safe
    )
    # Remove isolated speckle peaks without thickening a contour.
    padded = np.pad(outline, 1, mode="constant")
    neighbor_count = sum(
        padded[dy:dy + frame.shape[0], dx:dx + frame.shape[1]]
        for dy in range(3) for dx in range(3)
        if (dy, dx) != (1, 1)
    )
    return outline & (neighbor_count >= 1), effective


def add_green_gradient_outline(
    frame: np.ndarray,
    threshold: float | None = None,
    smoothing_radius: float = 1.4,
) -> tuple[np.ndarray, float]:
    mask, effective = gradient_outline_mask(frame, threshold, smoothing_radius)
    rgb = np.repeat(frame[..., None], 3, axis=2)
    rgb[mask] = GREEN
    return rgb, effective
