"""Image-adaptive, halo-limited enhancement built on the v29 directional response.

The manual slider remains a multiplier.  Automatic mode analyses each processed
frame independently, without changing the shared tone or denoising settings.
"""

import numpy as np

from edge_enhance_0913 import apply_edge_response, prepare_edge_response


def _mean3(source: np.ndarray) -> np.ndarray:
    padded = np.pad(source, 1, mode="edge")
    return sum(
        padded[dy:dy + source.shape[0], dx:dx + source.shape[1]]
        for dy in range(3) for dx in range(3)
    ) / 9.0


def analyze_edge_frame(frame: np.ndarray) -> dict:
    """Estimate contrast, fine texture and highlight headroom from display pixels."""
    if frame.ndim != 2 or frame.dtype != np.uint8:
        raise ValueError("Expected one uint8 grayscale frame")
    source = frame.astype(np.float32)
    active = frame > 0
    if np.count_nonzero(active) < 32:
        return {"contrast_p90_p10": 0.0, "texture_residual": 0.0,
                "edge_p85": 0.0, "saturated_fraction": 0.0, "auto_factor": 1.0}
    values = source[active]
    contrast = float(np.percentile(values, 90) - np.percentile(values, 10))
    mean = _mean3(source)
    texture = float(np.median(np.abs(source[active] - mean[active])))
    gx = np.abs(np.diff(source, axis=1, prepend=source[:, :1]))
    gy = np.abs(np.diff(source, axis=0, prepend=source[:1, :]))
    edge = float(np.percentile((gx + gy)[active], 85))
    saturated = float(np.mean(values >= 248.0))
    # Strong real transitions receive more emphasis; grain and clipped whites
    # reduce it.  Bounded gain avoids aggressive changes across adjacent frames.
    factor = float(np.clip(
        0.88 + 0.24 * contrast / (contrast + 90.0)
        + 0.28 * edge / (edge + 25.0)
        - 0.42 * texture / (texture + 12.0)
        - 0.30 * saturated,
        0.55, 1.25,
    ))
    return {"contrast_p90_p10": contrast, "texture_residual": texture,
            "edge_p85": edge, "saturated_fraction": saturated,
            "auto_factor": factor}


def prepare_adaptive_edge_response(frame: np.ndarray) -> np.ndarray:
    """Fuse v29 directional sharpening with a small one-sided bright-ridge cue.

    Clamping the negative response prevents the dark/bright double halo that a
    pure normal-direction sharpening kernel can leave beside a true contour.
    """
    directional = prepare_edge_response(frame)
    source = frame.astype(np.float32)
    smooth = _mean3(source)
    ridge = np.maximum(source - smooth - 2.0, 0.0)
    local_edge = np.abs(source - smooth)
    gate = np.clip((local_edge - 2.0) / 14.0, 0.0, 1.0)
    headroom = np.clip((252.0 - source) / 25.0, 0.0, 1.0)
    response = np.clip(directional, -3.0, 15.0)
    response += 0.32 * np.minimum(ridge, 18.0) * gate * headroom
    response[frame == 0] = 0.0
    return response.astype(np.float32)


def apply_adaptive_edge_response(
    frame: np.ndarray, response: np.ndarray, manual_gain: float,
    automatic: bool, profile: dict | None = None,
) -> tuple[np.ndarray, dict]:
    profile = analyze_edge_frame(frame) if profile is None else dict(profile)
    gain = float(manual_gain) * (profile["auto_factor"] if automatic else 1.0)
    enhanced = apply_edge_response(frame, response, gain)
    profile["effective_gain"] = gain
    profile["automatic"] = bool(automatic)
    return enhanced, profile


def enhance_frames(
    frames: np.ndarray, manual_gain: float, automatic: bool,
) -> tuple[np.ndarray, list[dict]]:
    if frames.ndim != 3 or frames.dtype != np.uint8:
        raise ValueError("Expected uint8 frames with shape [frame, row, column]")
    output = np.empty_like(frames)
    reports = []
    for index, frame in enumerate(frames):
        response = prepare_adaptive_edge_response(frame) if manual_gain > 0 else np.zeros(frame.shape, np.float32)
        output[index], report = apply_adaptive_edge_response(
            frame, response, manual_gain, automatic)
        reports.append(report)
    return output, reports
