"""Regression checks for v33 edge-aware diffusion and bright-area coverage."""

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from temporal_regions_v33 import _edge_guided_diffusion, segment_temporal_regions
from ultrasound_bin_gui import ProcessParams, export_results


class V33Tests(unittest.TestCase):
    @staticmethod
    def sequence() -> np.ndarray:
        frames = np.zeros((5, 96, 96), dtype=np.uint8)
        frames[:, 5:91, 5:91] = 35
        for index in range(5):
            frames[index, 22:54, 16 + index:48 + index] = 170
        frames[:, 57:82, 59:84] = 210
        frames[2, 62:74, 18:31] = 190
        return frames

    def test_diffusion_smooths_bright_texture_but_preserves_step(self):
        rng = np.random.default_rng(8)
        source = np.empty((3, 32, 32), dtype=np.uint8)
        for frame in source:
            frame[:, :16] = np.clip(80 + rng.integers(-12, 13, (32, 16)), 0, 255)
            frame[:, 16:] = np.clip(190 + rng.integers(-12, 13, (32, 16)), 0, 255)
        result = _edge_guided_diffusion(
            source, np.ones_like(source, dtype=bool),
            np.zeros_like(source, dtype=np.float32), 6, 42,
        )
        self.assertLess(float(result[:, :, 20:].std()),
                        float(source[:, :, 20:].std()))
        self.assertGreater(float(result[:, :, 20:].mean()) -
                           float(result[:, :, :12].mean()), 90)

    def test_bright_areas_are_covered_and_dark_area_uncolored(self):
        frames = self.sequence()
        labels, report = segment_temporal_regions(
            frames, cell_size=4, bright_threshold=145,
            min_area_pixels=16, max_regions=256,
        )
        bright = frames >= 145
        self.assertGreater(float(np.mean(labels[bright] > 0)), 0.90)
        self.assertFalse(np.any(labels[~bright] > 0))
        moving_ids = [int(labels[i, 36, 30 + i]) for i in range(5)]
        self.assertEqual(len(set(moving_ids)), 1)
        self.assertGreater(moving_ids[0], 0)
        self.assertGreater(int(labels[2, 68, 24]), 0)
        self.assertGreater(report["bright_pixel_coverage_percent"], 90)

    def test_persistence_slider_can_exclude_single_frame_area(self):
        frames = self.sequence()
        labels, _ = segment_temporal_regions(
            frames, cell_size=4, min_frames=3, min_area_pixels=16,
        )
        self.assertEqual(int(labels[2, 68, 24]), 0)
        self.assertGreater(int(labels[1, 36, 31]), 0)

    def test_export_preserves_gray_bin_and_diffusion_label_metadata(self):
        frames = self.sequence()[:3]
        labels, report = segment_temporal_regions(frames, cell_size=4)
        params = ProcessParams(
            width=96, height=96, region_enabled=True,
            gradient_outline_enabled=False,
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            gray_bin, png_dir, comparison = export_results(
                Path("raw_frames_u8.bin"), root, frames, frames, {}, params,
                region_labels=labels, region_report=report,
            )
            np.testing.assert_array_equal(
                np.fromfile(gray_bin, dtype=np.uint8).reshape(frames.shape), frames,
            )
            np.testing.assert_array_equal(
                np.fromfile(root / "raw_frames_u8_region_labels_u16.bin", dtype=np.uint16).reshape(labels.shape),
                labels,
            )
            with Image.open(png_dir / "frame_0001.png") as image:
                self.assertEqual(image.mode, "RGB")
            with Image.open(comparison) as image:
                self.assertEqual(image.width, 1024)
            metadata = json.loads((root / "raw_frames_u8_processing.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["temporal_brightness_regions"]["report"]["diffusion_iterations"], 6)


if __name__ == "__main__":
    unittest.main()
