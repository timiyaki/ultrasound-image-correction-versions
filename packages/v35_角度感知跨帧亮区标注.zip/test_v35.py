"""Tests for group-adaptive angle-aware v35 bright-region labels."""

import unittest

import numpy as np

from volume_regions_v35 import _multi_otsu_thresholds, segment_temporal_regions


class V35Tests(unittest.TestCase):
    @staticmethod
    def frames() -> np.ndarray:
        frames = np.zeros((4, 64, 64), dtype=np.uint8)
        frames[:, 4:60, 4:60] = 35
        for i in range(4):
            frames[i, 16 + i:32 + i, 12 + i:28 + i] = 190
        frames[:, 36:52, 38:54] = 220
        return frames

    def test_multi_otsu_separates_three_brightness_levels(self):
        values = np.repeat(np.array([25, 105, 205], dtype=np.uint8), 1000)
        low, high = _multi_otsu_thresholds(values)
        self.assertLess(low, high)
        self.assertLess(low, 105)
        self.assertLess(high, 205)

    def test_26_neighborhood_keeps_moving_area_id_across_frames(self):
        labels, report = segment_temporal_regions(
            self.frames(), frame_angles_deg=[0, 1, 2, 3], cell_size=4,
            min_frames=3,
        )
        ids = [int(labels[i, 23 + i, 19 + i]) for i in range(4)]
        self.assertGreater(ids[0], 0)
        self.assertEqual(len(set(ids)), 1)
        self.assertIn("26-neighbour", report["algorithm"])
        self.assertGreater(report["bright_pixel_coverage_percent"], 90)

    def test_large_angle_jump_stops_false_cross_frame_merge(self):
        frames = self.frames()[:2].copy()
        frames[1] = frames[0]
        labels, report = segment_temporal_regions(
            frames, frame_angles_deg=[0, 20], cell_size=4,
        )
        first = int(labels[0, 22, 18])
        second = int(labels[1, 22, 18])
        self.assertGreater(first, 0)
        self.assertGreater(second, 0)
        self.assertNotEqual(first, second)
        self.assertEqual(report["angle_adjacency"]["rejected_neighbor_pairs"], 1)

    def test_incomplete_angles_fall_back_to_ordered_stack(self):
        _, report = segment_temporal_regions(
            self.frames()[:2], frame_angles_deg=[0], cell_size=4,
        )
        self.assertIn("incomplete", report["angle_adjacency"]["mode"])


if __name__ == "__main__":
    unittest.main()
