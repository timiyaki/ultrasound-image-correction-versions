"""Regression tests for brightness-tier splitting and radial-shadow repair."""

import unittest

import numpy as np

from volume_pipeline_v37 import (
    SweepGeometry, full_volume_region_pipeline, suppress_radial_shadows,
)


class V37Tests(unittest.TestCase):
    @staticmethod
    def geometry() -> SweepGeometry:
        return SweepGeometry(
            tuple(float(x) for x in np.linspace(-10, 10, 9)),
            sample_scale_mm=0.5, scan_angle_deg=70,
            inner_radius_samples=0, sample_count=100,
            voxel_size_mm=2.0, near_field_exclusion_mm=8.0,
        )

    def test_radial_shadow_is_repaired_only_in_segmentation_features(self):
        frames = np.zeros((9, 80, 100), dtype=np.uint8)
        frames[:, 16:65, 20:80] = 190
        frames[:, 18:62, 49:51] = 15
        original = frames.copy()
        repaired, report = suppress_radial_shadows(frames, self.geometry(), 1.0)
        self.assertTrue(np.array_equal(frames, original))
        self.assertGreater(report["repaired_pixels"], 0)
        self.assertGreater(int(repaired[4, 40, 49]), int(frames[4, 40, 49]))
        self.assertEqual(int(repaired[4, 40, 10]), 0)

    def test_brightness_tiers_distinguish_adjacent_gray_levels(self):
        frames = np.zeros((9, 80, 100), dtype=np.uint8)
        frames[:, 18:65, 16:84] = 35
        frames[:, 24:55, 28:49] = 150
        frames[:, 24:55, 49:72] = 220
        result = full_volume_region_pipeline(
            frames, self.geometry(), bright_reference=125,
            min_brightness_gap=25, radial_shadow_strength=0,
        )
        self.assertTrue(result.report["brightness_tier_split_enabled"])
        left = int(result.projected_labels[4, 43, 40])
        right = int(result.projected_labels[4, 43, 60])
        self.assertNotEqual(left, 0)
        self.assertNotEqual(right, 0)
        self.assertNotEqual(left, right)

    def test_broad_dark_gap_is_not_filled_as_a_narrow_shadow(self):
        frames = np.zeros((9, 80, 100), dtype=np.uint8)
        frames[:, 16:65, 20:80] = 190
        frames[:, 18:62, 43:57] = 15
        repaired, _ = suppress_radial_shadows(frames, self.geometry(), 1.0)
        self.assertEqual(int(repaired[4, 40, 50]), 15)

    def test_full_pipeline_keeps_input_unchanged(self):
        frames = np.zeros((9, 80, 100), dtype=np.uint8)
        frames[:, 16:65, 20:80] = 190
        frames[:, 18:62, 49:51] = 15
        original = frames.copy()
        result = full_volume_region_pipeline(
            frames, self.geometry(), bright_reference=130,
            radial_shadow_strength=1.0,
        )
        self.assertTrue(np.array_equal(frames, original))
        self.assertGreater(result.report["radial_shadow_feature_repair"]["repaired_pixels"], 0)
        self.assertEqual(int(result.projected_labels[4, 40, 40]),
                         int(result.projected_labels[4, 40, 60]))


if __name__ == "__main__":
    unittest.main()
